---
name: humanize
description: Humanize existing or AI-generated writing by preserving evidence of a real human mind. Use when the user says HUMANIZE, asks to make writing sound genuinely human or like themselves, or wants to remove AI/copywriting polish while keeping meaning, specificity, humor, uncertainty, contradiction, natural rhythm, and lived detail.
---

# HUMANIZE

## Purpose

Use this skill when the user asks to HUMANIZE writing, make writing sound genuinely human, preserve their voice, or remove obvious AI/copywriting polish.

The goal is **not** to make AI writing look artificially imperfect.

The goal is to preserve and strengthen **evidence of a real human mind** in the writing.

Prioritize:

**THOUGHT → EXPERIENCE → LANGUAGE → STRUCTURE → POLISH**

Never reverse that into:

**STRUCTURE → LANGUAGE → THOUGHT**

Human writing should feel like someone noticed something, remembered something, judged something, doubted something, found something funny, changed their mind, got annoyed, made a mistake, or selected a detail because it genuinely stuck.

---

## When to use

Use this skill when the user says things like:

- HUMANIZE
- HUMANIZE this
- Run HUMANIZE
- Make this sound genuinely human
- Make this sound like me
- Remove the AI feel
- Make this less polished / less AI-ish
- Rewrite this so it feels like a real person wrote it

If the user provides an existing human draft, edit conservatively.

If the text is clearly AI-generated or generic, reconstruct more deeply.

---

## Core operating principle

**Do not make AI sound human. Stop AI from sanding the human out of the writing.**

---

## The central test

Before finalizing, ask:

**Could another smart person in the same industry have written this exact piece?**

If yes, the writing is probably still too generic.

Look for what belongs specifically to this person:

- a particular observation
- an oddly specific detail
- a frustration
- a mistake
- a remembered phrase
- a concrete example
- an opinion another person might not share
- a contradiction
- a moment of uncertainty
- something slightly unnecessary but revealing
- a natural joke or aside

Voice lives in **selection**, not in decorative adjectives.

---

## Workflow

### 1. Find the actual thought

Before rewriting, identify what the person is really trying to say.

Do not reduce the idea prematurely to a slogan.

Ask internally:

- What is the real point?
- Why does the person care?
- What made them think this?
- What part feels observed rather than generic?
- Where is the tension?
- What is unresolved?

Preserve nuance.

---

### 2. Find the human material

Prioritize material already present in the source:

- exact actions
- specific objects
- numbers
- times
- names of tools
- tiny inconveniences
- mistakes
- repeated attempts
- remembered wording
- unusual comparisons
- mildly embarrassing details
- contradictions
- moments where the person changes direction
- details that are not strictly necessary but feel lived

Do not fabricate biography or memories.

---

### 3. Prefer evidence over labels

Avoid naming an emotion when the scene already proves it.

Instead of:

> I was overwhelmed.

Prefer something concrete:

> By 4pm I’d answered emails, chased an invoice, fixed a broken link and still hadn’t touched the thing I opened my laptop to do.

Instead of:

> The process was frustrating.

Prefer:

> I had followed up three times and the invoice was still sitting there.

Instead of:

> Claude improved my productivity.

Prefer:

> Claude opened the sheet, found yesterday’s post, rewrote it twice and put both versions in Buffer.

Trust the reader.

---

### 4. Turn abstractions back into life

Be suspicious of noun-heavy business language:

- implementation
- optimization
- utilization
- alignment
- transformation
- execution
- personalization
- integration
- efficiency
- productivity
- scalability
- visibility
- ecosystem
- framework
- process
- workflow

These words are not banned.

Use them only when they are genuinely the most precise words.

Prefer people and tools **doing things**.

Instead of:

> the automation of my content repurposing workflow

Prefer:

> Claude takes the Instagram post, rewrites it for LinkedIn and Threads, and schedules both.

Prefer verbs, objects, observable actions.

---

### 5. Remove synthetic rhetoric

Be suspicious of repeated structures such as:

- It’s not X. It’s Y.
- You don’t need X. You need Y.
- This isn’t about X. It’s about Y.
- Less X. More Y.
- The problem isn’t X. It’s Y.
- Not because X, but because Y.
- The real shift is...
- That’s the difference between...
- And maybe that’s the point.

These structures are not forbidden.

Use them only when the underlying thought genuinely contains that contrast.

Do not invent an artificial first half just to make the second half sound stronger.

---

### 6. Question tidy threes

AI often creates suspiciously complete triplets:

- clarity, confidence and consistency
- faster, easier and smarter
- create, connect and convert
- strategy, systems and scale

Do not ban lists of three.

Ask whether there are actually three things.

If there are two, say two.

If there is one, say one.

Avoid synthetic completeness.

---

### 7. Remove transition anxiety

Be suspicious of transitions whose only function is announcing that the thought is about to move:

- Here’s the thing
- Here’s why
- But here’s where it gets interesting
- And this is where...
- The result?
- More importantly
- Ultimately
- At its core
- In other words
- What this means is
- The key takeaway
- So what does this mean?
- The best part?
- The truth is

Do not delete every instance automatically.

Delete the ones that add no meaning.

When the connection is obvious, simply move.

---

### 8. Allow associative movement

Do not force every paragraph into:

topic sentence → explanation → example → lesson → transition

Human thought may:

remember something → go sideways → make a joke → qualify the point → return → change slightly

Allow this when it feels connected to the person’s thinking.

Do not tighten every digression merely because it can be removed.

---

### 9. Let rhythm follow thought

Do not mechanically alternate short and long sentences.

Let complicated thoughts take space.

Let moments of impact contract.

Let some sentences be ordinary.

Let some paragraphs contain no quotable line.

Do not make every paragraph punchy.

Do not make every paragraph end with a mic-drop.

---

### 10. Use an aphorism budget

AI likes constant quotable lines.

Be suspicious of:

- That changed everything.
- That’s the real opportunity.
- That’s what freedom actually looks like.
- That’s the part nobody talks about.
- And maybe that’s the point.
- The real shift is...
- This is bigger than...
- That’s the difference between...

One memorable line is stronger than ten lines trying to be memorable.

---

### 11. Allow register changes

A real person can sound:

technical → casual → annoyed → funny → thoughtful → matter-of-fact

inside the same piece.

Do not enforce unnatural tonal consistency.

Do not smooth every ordinary or blunt sentence into polished “thought leadership.”

---

### 12. Preserve genuine uncertainty

Keep genuine phrases such as:

- I think
- maybe
- I guess
- I’m not sure
- I don’t remember
- I still don’t understand
- probably
- I may be wrong
- for some reason

when they are true to the person’s experience.

Do not insert uncertainty decoratively.

Do not remove it merely to sound authoritative.

---

### 13. Preserve contradiction

Do not flatten:

> I loved it, but I also hated what it was doing to me.

into:

> Although the experience had challenges, it was ultimately valuable.

People can hold two things at once.

Do not force struggle → realization → transformation.

Leave unresolved tension when it is real.

---

### 14. Preserve specific ignorance

Never fabricate coherence.

If the user does not remember why something happened, keep that uncertainty.

Do not turn:

> I honestly can’t remember why I first tried it.

into:

> I started using it because I needed a more efficient workflow.

A cleaner story is not always a truer story.

---

### 15. Use real details, not decorative details

Do not invent sensory writing just because vivid writing is considered “good.”

Avoid fake detail such as:

> The glow of my laptop lit the room while my coffee slowly went cold.

unless the user actually supplied or clearly implied those details.

Use observed details, not decorative details.

---

### 16. Keep unnecessary-but-revealing details

Not every sentence needs to advance the argument efficiently.

Preserve details like:

- chasing an invoice for the third time
- the random broken link that became urgent
- the old post still sitting in the sheet
- the one annoying task that never gets done
- the exact tool involved
- the small mistake that caused the whole problem

These create human residue.

---

### 17. Trust the reader

Do not always explain:

what happened → what it means → why it matters → what to learn → what to do next

If the scene proves the point, stop.

If the joke works, do not explain it.

If the reader can infer the emotion, let them.

---

### 18. Keep some sentences ordinary

Every sentence should not be:

clever
surprising
emotional
insightful
beautiful
compressed
memorable

Some sentences should simply tell us what happened.

Do not polish connective tissue until it becomes visible.

---

### 19. Do not synonym-swap automatically

Humans repeat words.

If the natural word is “business,” use “business” again.

Do not automatically cycle:

business → company → brand → venture → organization

just to avoid repetition.

Repetition is acceptable when natural.

---

### 20. Allow local ugliness

A sentence can be a little long.

A word can repeat.

A clause can arrive late.

A thought can contain parentheses.

A paragraph can be uneven.

Do not repair every irregularity.

Fix only what meaningfully harms clarity or rhythm.

---

## Modes

### MODE A — Existing human draft

Use a conservative edit.

Priority order:

1. Preserve meaning.
2. Preserve unusual phrasing.
3. Preserve specific details.
4. Preserve humor.
5. Preserve uncertainty.
6. Preserve emotional rough edges.
7. Preserve personal rhythm.
8. Improve clarity only where needed.
9. Remove obvious AI/copywriting patterns.
10. Polish lightly.

Think like an editor, not a ghostwriter.

Avoid indiscriminately “improving clarity and flow.”

---

### MODE B — AI-generated or generic draft

Reconstruct more deeply.

Strip the text back to:

- actual claim
- useful facts
- genuine examples
- necessary story
- necessary CTA

Then rebuild around concrete action, specific thought, and natural rhythm.

Do not preserve an AI structure just because the grammar is good.

---

### MODE C — Write from scratch

Use only grounded material from:

- the current conversation
- supplied stories
- stated opinions
- actual examples
- approved voice examples
- clearly known constraints

Do not fabricate biography.

If source material is sparse, keep the writing simpler rather than inventing personality.

---

### MODE D — Social content

Do not default to:

Hook → agitation → three points → realization → takeaway → CTA

Use structure only when the content needs it.

Hooks should sound like something the person would actually say.

CTAs can be simple.

Do not over-sell the CTA.

---

## AI-smell pass

Before finalizing, scan for:

1. Manufactured “not X, Y” contrasts.
2. Suspicious three-part lists.
3. Abstract nouns replacing actions.
4. Business jargon where ordinary language works.
5. Transition announcements.
6. Excessive cause-and-effect explanation.
7. Every paragraph having an obvious rhetorical job.
8. Every paragraph ending strongly.
9. Excessive quotable sentences.
10. Perfectly symmetrical sentence structures.
11. Uniform sentence lengths.
12. Generic emotional adjectives.
13. Fake vulnerability.
14. Fake uncertainty.
15. Generic examples.
16. Decorative sensory details.
17. Constant motivational framing.
18. Excessive reader coaching.
19. Synthetic conversational markers.
20. Synonym swapping.
21. Unnecessary summary paragraphs.
22. Neat struggle-to-transformation arcs.
23. Global tonal consistency.
24. Over-explaining what the reader already understood.
25. Any sentence that sounds impressive but does not sound observed.

Do not mechanically fix all of these.

Judge whether each instance arose naturally.

The goal is not the absence of rhetoric.

The goal is the absence of **rhetorical automation**.

---

## Evidence-of-mind test

Before finishing, ask whether the piece contains evidence that a specific person:

- noticed something
- remembered something
- wanted something
- judged something
- found something funny
- was annoyed by something
- changed their mind
- did not know something
- made a mistake
- selected one detail over another

If none of those are visible, the writing may be competent but still feel generated.

---

## Final quality test

The final writing should satisfy:

### TRUTH
Faithful to what the person actually knows, believes, or experienced.

### SPECIFICITY
Enough concrete reality to belong to someone.

### IRREGULARITY
The language is not mechanically uniform.

### RESTRAINT
It does not explain, summarize, or polish beyond necessity.

### VOICE
The wording reflects the person’s actual way of seeing the subject rather than generic “good writing.”
