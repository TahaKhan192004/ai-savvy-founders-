# AI Writing Patterns to Watch

These are not absolute bans. Human writers use many of these structures too.

The issue is **density, repetition, and automatic use**.

## Manufactured contrast

Common forms:

- It’s not X. It’s Y.
- You don’t need X. You need Y.
- This isn’t about X. It’s about Y.
- Less X. More Y.
- The problem isn’t X. It’s Y.
- Not because X, but because Y.

Use only when the contrast is real.

Do not invent X merely to make Y sound more dramatic.

## Suspicious triplets

Examples:

- clarity, confidence, consistency
- faster, easier, smarter
- create, connect, convert
- strategy, systems, scale

Ask whether all three genuinely belong.

## Transition announcements

Examples:

- Here’s the thing
- Here’s why
- This is where it gets interesting
- The result?
- More importantly
- Ultimately
- At its core
- In other words
- The key takeaway
- What this means is
- The truth is

Many can simply be deleted.

## Synthetic conversationality

Examples:

- Honestly?
- Let that sink in.
- Read that again.
- Sound familiar?
- Game changer.
- Spoiler alert.
- And that’s okay.
- You’re not alone.
- Here’s the thing...

Do not sprinkle these into writing merely to simulate intimacy.

## Abstract business language

Common examples:

- leverage
- streamline
- elevate
- empower
- unlock
- optimize
- seamlessly
- strategic
- ecosystem
- framework
- alignment
- transformation
- implementation
- visibility
- scalability
- meaningful
- powerful

Use only when precise.

Prefer actions when possible.

## Nounification

AI often turns actions into nouns.

Instead of:

> We changed how we follow up with leads.

AI-like:

> We implemented a transformation of our lead follow-up process.

Turn concepts back into people or tools doing things.

## Too much causality

Watch for:

- therefore
- which means
- as a result
- that’s why
- this allows
- the reason is
- consequently

Do not explain causal relationships the reader already understands.

## Perfect emotional arcs

Common pattern:

problem → struggle → realization → growth → lesson

Life often stays unresolved.

Preserve ambiguity and contradiction when real.

## Over-explanation

AI often:

1. tells the story
2. interprets the story
3. explains the lesson
4. summarizes the lesson
5. gives the takeaway

Stop earlier.

## Constant mic-drop lines

Examples:

- That changed everything.
- That’s the real opportunity.
- That’s the part nobody talks about.
- That’s what freedom actually looks like.
- And maybe that’s the point.

Strong lines need ordinary lines around them.

## Generic emotional labels

Examples:

- overwhelming
- frustrating
- exciting
- powerful
- transformative
- incredible
- challenging

Prefer the evidence.

## Generic examples

Examples:

> A small business owner might use AI to...

Prefer examples grounded in the user’s actual work.

## Decorative sensory detail

Do not manufacture:

- glowing screens
- cold coffee
- late-night silence
- warm sunlight
- buzzing phones

unless actually grounded.

## Global tone consistency

AI often tries to keep the whole piece equally:

- warm
- polished
- professional
- inspiring
- conversational

Humans change register.

## Synonym cycling

Do not replace repeated natural words merely to avoid repetition.

Example:

business → company → brand → organization → venture

If “business” is the right word, repeat it.

## Synthetic completeness

AI likes neat packages.

Do not force:

- exactly three examples
- exactly five lessons
- a tidy final moral
- a fully resolved argument

Let reality stay uneven.
