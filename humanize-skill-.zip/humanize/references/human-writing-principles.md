# Human Writing Principles

This reference supports the HUMANIZE skill.

It is not a list of tricks. It is a description of recurring qualities found in strong pre-generative-AI human writing.

## 1. Human writing often looks like thought in motion

Good human prose does not always feel as though the writer knew the final sentence before writing the first.

Thought may move associatively:

- observation
- memory
- qualification
- joke
- return
- contradiction
- new conclusion

This is different from random wandering. The movement is connected by the person’s actual associations.

## 2. Human specificity is often oddly selective

Humans remember details that are not perfectly useful to the argument.

The detail may be:

- the exact thing someone said
- the third follow-up
- the broken link
- the bill that still arrives
- the weird object in the room
- the thing that happened right before the important thing

This kind of specificity feels remembered rather than inserted.

## 3. Humans leave inference to the reader

A strong scene often carries its own emotional meaning.

If a person says:

> I had followed up three times and the invoice was still sitting there.

the reader does not need:

> It was incredibly frustrating.

The evidence is stronger than the label.

## 4. Humans are not uniformly profound

Most real prose contains:

- ordinary sentences
- setup
- description
- functional connective tissue
- occasional awkwardness

Strong lines work partly because everything around them is not trying to be strong.

## 5. Humans switch registers

A person can move from:

- technical
- intellectual
- casual
- blunt
- funny
- uncertain
- reflective

without announcing the change.

Real voice has range.

## 6. Humans repeat themselves

Natural repetition can preserve thought.

A person may reuse the same noun because it is still the right noun.

They may restart a sentence.

They may say:

> because... because

or repeat a phrase for emphasis.

Do not eliminate repetition automatically.

## 7. Humans tolerate unresolved thought

People can say:

- I think
- maybe
- I still don’t know
- I’m not completely sure
- I loved it and hated it
- I still do this sometimes

A human narrator does not always stand above the story with a finished lesson.

## 8. Humans use details that reveal the writer

The best examples often do two jobs:

1. illustrate the idea
2. reveal something about the person

Generic example:

> A founder might use AI to automate customer follow-up.

Human example:

> I have one that checks whether I followed up after a call because apparently I cannot be trusted to remember this myself.

The second one contains the author.

## 9. Human sentence rhythm follows cognition

Sentence-length variation should emerge from the thought.

Longer sentences may carry complexity.

Very short sentences may arrive at moments of impact.

Do not manufacture “burstiness.”

## 10. Human writing is selective, not comprehensive

A model often tries to explain the whole thing.

A human writer often chooses one slice.

A specific slice can imply the larger system.

This is especially important in captions, social posts, and personal essays.

## 11. Human humor often derails slightly

Real humor may not serve the conversion goal.

It may be a private association, an aside, a tiny embarrassment, or a phrase the writer simply finds funny.

Do not force jokes, but do not cut them merely because they are not strategically useful.

## 12. Humans use the locally natural word

Human prose can contain:

- an advanced technical term
- a plain everyday word
- slang
- something blunt

in the same piece.

Do not standardize the whole text into one level of sophistication.

## 13. Human voice is situated

People do not have one fixed tone.

They sound different:

- with a client
- in a Reel
- in a vulnerable story
- while teaching
- while annoyed
- while joking

A strong voice system preserves identity across changing registers rather than flattening everything into one tone.

## 14. Human writing contains evidence of mind

The strongest signal is not grammar, slang, punctuation, or imperfection.

It is evidence that someone:

- noticed
- remembered
- judged
- doubted
- selected
- omitted
- changed their mind
- found something funny
- carried some unresolved feeling

That is the target.
