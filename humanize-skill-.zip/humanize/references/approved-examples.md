# Approved Humanized Examples

These examples are drawn from user-provided writing and approved rewrites.

Use them to understand the target feel.

Do **not** copy their exact phrasing into unrelated writing.

---

## Example 1 — Founder busywork story

### What works

The approved version uses small turns of thought instead of a polished founder-story arc.

Useful qualities:

- “I mean, I had.” interrupts the thought naturally.
- The list of tasks is concrete: emails, research, invoice chasing, follow-up, broken link.
- “You know those days.” assumes shared experience without over-explaining.
- The narrator admits something “embarrassingly obvious.”
- Humor appears in the idea of 80 AI “employees.”
- The emotional payoff is shown through days disappearing into tiny jobs rather than packaged into a motivational lesson.
- The close remains conversational and slightly amused rather than grand.

### Voice lesson

Prefer:

> You’ve been busy for 8 hours, but if someone asks what you actually moved forward in the business… you’re like, ummm.

over:

> Despite being productive, I realized I was not focusing on high-impact work.

The first contains a person.

---

## Example 2 — Instagram repurposing post

### User source idea

A strong Instagram post did well, stayed on Instagram, and never made it to LinkedIn or Threads because repurposing was boring and repeatedly fell to the bottom of the list.

### Approved humanized direction

Useful qualities:

- Starts with a very ordinary fact: the post is still on Instagram.
- Repeats “Never made it...” naturally.
- Admits the real reason: the writer simply was not going to keep rewriting the same thing manually.
- Includes the little aside that there were “quite a few others.”
- Explains Claude Code in concrete actions: opens sheet, finds post, writes two versions, schedules, ticks it off.
- Includes a specific fake-AI line (“Here’s the thing about content repurposing...”) as humor.
- Draws a real boundary around autonomy: AI may reshape existing words but not invent opinions and publish them under the writer’s name.
- Ends with the ordinary consequence: the writer goes to bed and the old post quietly reaches two more platforms.

### Voice lesson

Prefer:

> So it sat there.

> Along with quite a few others.

over:

> As a result, my backlog of unrepurposed content continued to grow.

The first has residue.

---

## Example 3 — Natural boundaries around AI

Useful approved idea:

> I’m comfortable with that because the boundary is pretty clear in my head: it can take something I’ve already said and reshape it for another platform.

> It can’t decide what I think.

> And it definitely can’t invent something and put my name on it.

Why this works:

- The rule sounds discovered rather than branded.
- It is not converted into a “3-step AI governance framework.”
- The second sentence is short because the thought itself is firm.
- The third sentence sounds like a person drawing a line, not a consultant explaining policy.

---

## Voice preferences inferred from approved examples

Favor:

- conversational but intelligent
- specific over abstract
- dry/light humor
- occasional self-deprecation
- ordinary words next to technical words
- short interruptions
- natural repetition
- slight messiness
- confidence without guru voice
- strong opinions when genuinely held
- direct statements
- concrete tools and actions
- understated endings

Avoid:

- synthetic inspiration
- “thought leader” tone
- excessive polish
- fake vulnerability
- too many em dashes
- constant “here’s the thing”
- jargon-heavy AI language
- every paragraph ending in a quote-worthy line
- over-explaining the lesson
- neat binary contrasts unless genuinely necessary
