"""Shared tables and span logic for the invisible-character passes.

Pure standard library. No third-party imports, no network, no subprocess.
"""

import re
import unicodedata

# Characters that carry no visible glyph and no layout meaning in Latin prose.
# `default` marks the ones removed without asking. The rest are reported and
# left alone unless the caller opts in, because they change rendering or carry
# real linguistic meaning in some scripts.
INVISIBLES = {
    "​": ("ZERO WIDTH SPACE", "zero-width", True),
    "⁠": ("WORD JOINER", "zero-width", True),
    "﻿": ("ZERO WIDTH NO-BREAK SPACE (BOM)", "zero-width", True),
    "­": ("SOFT HYPHEN", "zero-width", True),
    "᠎": ("MONGOLIAN VOWEL SEPARATOR", "zero-width", True),
    "؜": ("ARABIC LETTER MARK", "bidi", False),
    "‎": ("LEFT-TO-RIGHT MARK", "bidi", False),
    "‏": ("RIGHT-TO-LEFT MARK", "bidi", False),
    "‪": ("LEFT-TO-RIGHT EMBEDDING", "bidi", False),
    "‫": ("RIGHT-TO-LEFT EMBEDDING", "bidi", False),
    "‬": ("POP DIRECTIONAL FORMATTING", "bidi", False),
    "‭": ("LEFT-TO-RIGHT OVERRIDE", "bidi", False),
    "‮": ("RIGHT-TO-LEFT OVERRIDE", "bidi", False),
    "⁦": ("LEFT-TO-RIGHT ISOLATE", "bidi", False),
    "⁧": ("RIGHT-TO-LEFT ISOLATE", "bidi", False),
    "⁨": ("FIRST STRONG ISOLATE", "bidi", False),
    "⁩": ("POP DIRECTIONAL ISOLATE", "bidi", False),
    # Context-sensitive. Real letters depend on these in Arabic, Persian,
    # and the Indic scripts, and emoji sequences are built from ZWJ.
    "‌": ("ZERO WIDTH NON-JOINER", "joiner", False),
    "‍": ("ZERO WIDTH JOINER", "joiner", False),
}

# Unusual spaces. These are visible as whitespace and usually deliberate
# (typography, CJK layout, non-breaking runs), so nothing here is a default
# removal. Reported so a human can decide.
SPACES = {
    " ": "NO-BREAK SPACE",
    " ": "EN QUAD", " ": "EM QUAD",
    " ": "EN SPACE", " ": "EM SPACE",
    " ": "THREE-PER-EM SPACE", " ": "FOUR-PER-EM SPACE",
    " ": "SIX-PER-EM SPACE", " ": "FIGURE SPACE",
    " ": "PUNCTUATION SPACE", " ": "THIN SPACE",
    " ": "HAIR SPACE", " ": "MEDIUM MATHEMATICAL SPACE",
    "　": "IDEOGRAPHIC SPACE",
}

# Cyrillic and Greek letters whose common forms are visually identical to
# Latin. Only meaningful when one appears inside an otherwise-Latin word.
HOMOGLYPHS = {
    "а": "a", "е": "e", "о": "o", "р": "p", "с": "c",
    "х": "x", "у": "y", "і": "i", "ј": "j", "һ": "h",
    "А": "A", "В": "B", "Е": "E", "К": "K", "М": "M",
    "Н": "H", "О": "O", "Р": "P", "С": "C", "Т": "T",
    "У": "Y", "Х": "X", "Ѕ": "S", "І": "I", "Ј": "J",
    "Α": "A", "Β": "B", "Ε": "E", "Ζ": "Z", "Η": "H",
    "Ι": "I", "Κ": "K", "Μ": "M", "Ν": "N", "Ο": "O",
    "Ρ": "P", "Τ": "T", "Υ": "Y", "Χ": "X",
    "ο": "o", "α": "a", "ε": "e", "ρ": "p", "υ": "u",
}

LATIN = re.compile(r"[A-Za-z]")
# Scripts whose letters legitimately take a joiner on either side.
JOINER_SCRIPTS = re.compile(
    r"[؀-ۿݐ-ݿࡰ-࢟ࢠ-ࣿ"   # Arabic
    r"ऀ-෿"                                             # Indic
    r"ក-៿"                                             # Khmer
    r"ﭐ-﷿ﹰ-﻿]"                               # Arabic forms
)
EMOJI_ISH = re.compile(
    r"[\U0001f000-\U0001faff☀-➿\U0001f1e6-\U0001f1ff⬀-⯿️]"
)


def is_tag_char(ch):
    """U+E0000..U+E007F. The real steganographic channel: a full ASCII
    alphabet that renders as nothing at all."""
    return 0xE0000 <= ord(ch) <= 0xE007F


def is_variation_selector(ch):
    return 0xFE00 <= ord(ch) <= 0xFE0F or 0xE0100 <= ord(ch) <= 0xE01EF


def char_name(ch):
    try:
        return unicodedata.name(ch)
    except ValueError:
        return "U+%04X" % ord(ch)


def _near(text, i, pattern, reach=1):
    lo = max(0, i - reach)
    hi = min(len(text), i + reach + 1)
    return bool(pattern.search(text[lo:i])) or bool(pattern.search(text[i + 1:hi]))


def joiner_is_meaningful(text, i):
    """True when a ZWJ/ZWNJ at position i is doing real work: gluing an emoji
    sequence, or shaping an Arabic/Indic word."""
    return _near(text, i, EMOJI_ISH) or _near(text, i, JOINER_SCRIPTS)


def in_flag_sequence(text, i):
    """Tag characters after U+1F3F4 build subdivision flags (England,
    Scotland, Wales). Those are legitimate; loose tag chars are not."""
    j = i - 1
    while j >= 0 and is_tag_char(text[j]):
        j -= 1
    return j >= 0 and text[j] == "\U0001f3f4"


def homoglyph_in_latin_word(text, i):
    """True when a Cyrillic/Greek lookalike sits inside a run of Latin
    letters, which is the only case where it is likely unintended."""
    j = i - 1
    while j >= 0 and (text[j].isalpha() or text[j] in "'’"):
        j -= 1
    k = i + 1
    while k < len(text) and (text[k].isalpha() or text[k] in "'’"):
        k += 1
    word = text[j + 1:k]
    return len(word) > 1 and LATIN.search(word) is not None


FENCE = re.compile(r"^([ \t]*)(`{3,}|~{3,}).*$", re.M)
INLINE_CODE = re.compile(r"(`+)(?:(?!\1).)*?\1", re.S)
HTML_BLOCK = re.compile(
    r"<(script|style|code|pre|kbd|samp)\b[^>]*>.*?</\1\s*>", re.S | re.I)
HTML_TAG = re.compile(r"<[^>]+>")
URL = re.compile(r"(?:https?://|www\.|mailto:)[^\s<>()\[\]\"']+")
MD_LINK_TARGET = re.compile(r"\]\(([^)]*)\)")
FRONTMATTER = re.compile(r"\A---\r?\n.*?\r?\n---[ \t]*\r?\n", re.S)


def protected_spans(text, fmt="auto", name=""):
    """Byte-agnostic character spans that must never be edited: code, markup,
    link targets, URLs, and YAML frontmatter.

    Returns a sorted, merged list of (start, end) character offsets.
    """
    if fmt == "auto":
        low = name.lower()
        if low.endswith((".html", ".htm", ".xml", ".svg")):
            fmt = "html"
        elif low.endswith((".md", ".markdown", ".mdx")):
            fmt = "md"
        else:
            fmt = "txt"

    spans = []

    if fmt in ("md", "html"):
        m = FRONTMATTER.match(text)
        if m:
            spans.append(m.span())

    if fmt == "md":
        opens = []
        for m in FENCE.finditer(text):
            opens.append(m)
        i = 0
        while i < len(opens):
            start = opens[i]
            end = None
            for j in range(i + 1, len(opens)):
                if opens[j].group(2)[0] == start.group(2)[0]:
                    end = opens[j]
                    break
            if end is None:
                spans.append((start.start(), len(text)))
                break
            spans.append((start.start(), end.end()))
            i = opens.index(end) + 1
        for m in INLINE_CODE.finditer(text):
            spans.append(m.span())
        for m in MD_LINK_TARGET.finditer(text):
            spans.append(m.span(1))

    if fmt == "html":
        for m in HTML_BLOCK.finditer(text):
            spans.append(m.span())
        for m in HTML_TAG.finditer(text):
            spans.append(m.span())

    for m in URL.finditer(text):
        spans.append(m.span())

    if not spans:
        return []
    spans.sort()
    merged = [list(spans[0])]
    for a, b in spans[1:]:
        if a <= merged[-1][1]:
            merged[-1][1] = max(merged[-1][1], b)
        else:
            merged.append([a, b])
    return [tuple(s) for s in merged]


def in_spans(i, spans):
    lo, hi = 0, len(spans)
    while lo < hi:
        mid = (lo + hi) // 2
        a, b = spans[mid]
        if i < a:
            hi = mid
        elif i >= b:
            lo = mid + 1
        else:
            return True
    return False


def line_col(text, i, _cache={}):
    key = id(text)
    starts = _cache.get(key)
    if starts is None or _cache.get((key, "len")) != len(text):
        starts = [0]
        for m in re.finditer(r"\n", text):
            starts.append(m.end())
        _cache.clear()
        _cache[key] = starts
        _cache[(key, "len")] = len(text)
    lo, hi = 0, len(starts) - 1
    while lo < hi:
        mid = (lo + hi + 1) // 2
        if starts[mid] <= i:
            lo = mid
        else:
            hi = mid - 1
    return lo + 1, i - starts[lo] + 1


def find_marks(text, fmt="auto", name="", aggressive_homoglyphs=False):
    """Locate every suspicious character. Returns a list of dicts.

    `action` is what the default clean pass would do: "remove", "report".
    `confidence` is how sure we are the character is unintended.
    """
    spans = protected_spans(text, fmt, name)
    out = []
    for i, ch in enumerate(text):
        prot = in_spans(i, spans)
        hit = None

        if ch in INVISIBLES:
            label, cls, default = INVISIBLES[ch]
            if cls == "joiner":
                if joiner_is_meaningful(text, i):
                    hit = (label, cls, "report", "likely_intended")
                else:
                    hit = (label, cls, "remove", "probable")
            elif default:
                hit = (label, cls, "remove", "confirmed")
            else:
                hit = (label, cls, "report", "informational")

        elif is_tag_char(ch):
            if in_flag_sequence(text, i):
                hit = ("TAG CHARACTER (flag sequence)", "tag", "report",
                       "likely_intended")
            else:
                hit = ("TAG CHARACTER", "tag", "remove", "confirmed")

        elif is_variation_selector(ch):
            hit = (char_name(ch), "variation-selector", "report",
                   "likely_intended")

        elif ch in SPACES:
            hit = (SPACES[ch], "space", "report", "informational")

        elif ch in HOMOGLYPHS:
            if homoglyph_in_latin_word(text, i):
                act = "remove" if aggressive_homoglyphs else "report"
                hit = ("%s (looks like %r)" % (char_name(ch), HOMOGLYPHS[ch]),
                       "homoglyph", act, "probable")

        if hit is None:
            continue
        label, cls, action, conf = hit
        if prot:
            action, conf = "report", "protected"
        line, col = line_col(text, i)
        out.append({
            "offset": i, "line": line, "col": col,
            "char": "U+%04X" % ord(ch), "name": label,
            "class": cls, "action": action, "confidence": conf,
            "protected": prot,
        })
    return out
