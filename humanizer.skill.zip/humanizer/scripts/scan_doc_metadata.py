#!/usr/bin/env python3
"""Report (and optionally strip) authoring metadata in text documents.

    scan_doc_metadata.py FILE [--json]
    scan_doc_metadata.py FILE --strip -o OUT

Handles Markdown/MDX YAML frontmatter, HTML <meta> and generator comments, and
DOCX/ODT package properties. Body text is never touched: stripping removes only
the metadata fields listed in the report.

Not an image or PDF tool. EXIF, XMP, and C2PA live in binary containers and
need exiftool or c2patool; this script does not touch them and does not pretend
to. See the skill's `references/provenance.md`.

Exit status: 0 nothing actionable (no findings, or --strip cleared them),
1 findings remain, 2 usage error.
"""

import argparse
import json
import os
import re
import sys
import zipfile

# Frontmatter keys that name the tool or the author.
TOOL_KEYS = {
    "generator", "generated_by", "generatedby", "created_with", "createdwith",
    "ai", "ai_generated", "aigenerated", "model", "llm", "tool", "engine",
    "assistant", "producer", "application",
}
PERSON_KEYS = {"author", "authors", "creator", "last_modified_by", "byline"}

FRONTMATTER = re.compile(r"\A(---[ \t]*\r?\n)(.*?)(\r?\n---[ \t]*\r?\n)", re.S)
YAML_KEY = re.compile(r"^([A-Za-z_][A-Za-z0-9_.-]*)[ \t]*:(.*)$")
META_TAG = re.compile(
    r"""<meta\b[^>]*\bname\s*=\s*["']?(?P<name>[\w:.-]+)["']?[^>]*>""", re.I)
META_CONTENT = re.compile(r"""\bcontent\s*=\s*["'](?P<v>[^"']*)["']""", re.I)
HTML_COMMENT = re.compile(r"<!--(?P<body>.*?)-->", re.S)
GEN_HINT = re.compile(
    r"\b(generated|created|produced|written)\s+(by|with|using)\b|"
    r"\b(chatgpt|gpt-?[0-9]|claude|gemini|copilot|jasper|writesonic|"
    r"notion ai|grammarly)\b", re.I)

DOCX_PARTS = {
    "docProps/core.xml": ["dc:creator", "cp:lastModifiedBy", "dc:title",
                          "dc:subject", "dc:description", "cp:keywords",
                          "cp:category", "cp:contentStatus"],
    "docProps/app.xml": ["Application", "Company", "Manager", "AppVersion",
                         "Template"],
    "meta.xml": ["meta:generator", "dc:creator", "meta:initial-creator"],
}
XML_FIELD = re.compile(r"<(?P<tag>[\w:.-]+)(\s[^>]*)?>(?P<val>[^<]*)</(?P=tag)>")


def kind_of(path):
    low = path.lower()
    if low.endswith((".md", ".markdown", ".mdx")):
        return "markdown"
    if low.endswith((".html", ".htm", ".xhtml")):
        return "html"
    if low.endswith((".docx", ".odt", ".pptx", ".xlsx", ".epub")):
        return "package"
    return "text"


def scan_markdown(text):
    out = []
    m = FRONTMATTER.match(text)
    if not m:
        return out
    body_start = m.start(2)
    offset = body_start
    for line in m.group(2).splitlines(True):
        km = YAML_KEY.match(line)
        if km:
            key = km.group(1)
            low = key.lower()
            if low in TOOL_KEYS or low in PERSON_KEYS:
                out.append({
                    "where": "frontmatter",
                    "field": key,
                    "value": km.group(2).strip(),
                    "class": "tool" if low in TOOL_KEYS else "person",
                    "span": [offset, offset + len(line)],
                })
        offset += len(line)
    return out


def scan_html(text):
    out = []
    for m in META_TAG.finditer(text):
        name = m.group("name")
        low = name.lower()
        if low in TOOL_KEYS or low in PERSON_KEYS:
            cm = META_CONTENT.search(m.group(0))
            out.append({
                "where": "meta tag",
                "field": name,
                "value": cm.group("v") if cm else "",
                "class": "tool" if low in TOOL_KEYS else "person",
                "span": list(m.span()),
            })
    for m in HTML_COMMENT.finditer(text):
        if GEN_HINT.search(m.group("body")):
            out.append({
                "where": "comment",
                "field": "<!-- ... -->",
                "value": " ".join(m.group("body").split())[:120],
                "class": "tool",
                "span": list(m.span()),
            })
    return out


def scan_package(path):
    out = []
    try:
        with zipfile.ZipFile(path) as zf:
            names = set(zf.namelist())
            for part, fields in DOCX_PARTS.items():
                if part not in names:
                    continue
                try:
                    xml = zf.read(part).decode("utf-8", "replace")
                except KeyError:
                    continue
                for m in XML_FIELD.finditer(xml):
                    tag, val = m.group("tag"), m.group("val").strip()
                    if tag in fields and val:
                        out.append({
                            "where": part,
                            "field": tag,
                            "value": val,
                            "class": "tool" if tag in (
                                "Application", "meta:generator", "Company",
                                "Template", "AppVersion") else "person",
                            "span": None,
                        })
    except (zipfile.BadZipFile, OSError) as exc:
        raise RuntimeError("cannot read package: %s" % exc)
    return out


def strip_text(text, findings):
    """Remove the reported spans, and the whole line when nothing else is on
    it. Later spans first so earlier offsets stay valid."""
    spans = sorted((f["span"] for f in findings if f["span"]), reverse=True)
    for a, b in spans:
        # widen to the full line when the rest of it is only whitespace
        ls = text.rfind("\n", 0, a) + 1
        le = text.find("\n", b)
        le = len(text) if le == -1 else le + 1
        if not text[ls:a].strip() and not text[b:le].strip():
            a, b = ls, le
        text = text[:a] + text[b:]
    return text


def strip_package(src, dst, findings):
    fields = {f["field"] for f in findings}
    parts = {f["where"] for f in findings}
    with zipfile.ZipFile(src) as zin:
        infos = zin.infolist()
        with zipfile.ZipFile(dst, "w", zipfile.ZIP_DEFLATED) as zout:
            for info in infos:
                data = zin.read(info.filename)
                if info.filename in parts:
                    xml = data.decode("utf-8", "replace")

                    def blank(m):
                        if m.group("tag") in fields:
                            return "<%s></%s>" % (m.group("tag"), m.group("tag"))
                        return m.group(0)

                    xml = XML_FIELD.sub(blank, xml)
                    data = xml.encode("utf-8")
                zout.writestr(info, data)


def main(argv=None):
    ap = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("input")
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--strip", action="store_true")
    ap.add_argument("-o", "--output")
    args = ap.parse_args(argv)

    if args.strip and not args.output:
        print("--strip needs -o OUT", file=sys.stderr)
        return 2
    if not os.path.exists(args.input):
        print("no such file: %s" % args.input, file=sys.stderr)
        return 2

    kind = kind_of(args.input)
    try:
        if kind == "package":
            findings = scan_package(args.input)
            text = None
        else:
            with open(args.input, encoding="utf-8", errors="replace") as fh:
                text = fh.read()
            findings = (scan_markdown(text) if kind == "markdown"
                        else scan_html(text) if kind == "html" else [])
    except (OSError, RuntimeError) as exc:
        print("%s: %s" % (args.input, exc), file=sys.stderr)
        return 2

    if args.strip:
        if kind == "package":
            strip_package(args.input, args.output, findings)
        elif text is not None:
            out = strip_text(text, findings) if findings else text
            with open(args.output, "w", encoding="utf-8") as fh:
                fh.write(out)
        if not args.json:
            print("wrote %s (%d field(s) cleared)"
                  % (args.output, len(findings)), file=sys.stderr)

    if args.json:
        json.dump({"input": args.input, "kind": kind,
                   "count": len(findings), "findings": findings},
                  sys.stdout, indent=2, ensure_ascii=False)
        sys.stdout.write("\n")
    elif not findings:
        print("%s: no authoring metadata found (%s)" % (args.input, kind))
    else:
        print("%s: %d field(s) (%s)" % (args.input, len(findings), kind))
        for f in findings:
            val = f["value"]
            if len(val) > 60:
                val = val[:57] + "..."
            print("  %-14s %-20s %-7s %s"
                  % (f["where"], f["field"], f["class"], val))
    # After a successful strip nothing is left to act on, so report success.
    # Scan-only keeps 1 so it can gate a chain or a CI step.
    return 0 if (args.strip or not findings) else 1


if __name__ == "__main__":
    sys.exit(main())
