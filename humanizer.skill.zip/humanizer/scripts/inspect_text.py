#!/usr/bin/env python3
"""Report invisible and lookalike characters in a text file. Reads only.

    inspect_text.py FILE [--json] [--format md|html|txt] [--aggressive-homoglyphs]
    cat FILE | inspect_text.py -

Exit status: 0 nothing actionable, 1 actionable findings, 2 usage error.
"""

import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import marks  # noqa: E402


def read(path):
    if path == "-":
        return sys.stdin.read()
    with open(path, "r", encoding="utf-8", errors="surrogatepass") as fh:
        return fh.read()


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("input")
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--format", default="auto",
                    choices=["auto", "md", "html", "txt"])
    ap.add_argument("--aggressive-homoglyphs", action="store_true")
    args = ap.parse_args(argv)

    try:
        text = read(args.input)
    except OSError as exc:
        print("cannot read %s: %s" % (args.input, exc), file=sys.stderr)
        return 2

    name = "" if args.input == "-" else args.input
    hits = marks.find_marks(text, args.format, name, args.aggressive_homoglyphs)
    actionable = [h for h in hits if h["action"] == "remove"]

    if args.json:
        json.dump({
            "input": args.input,
            "chars": len(text),
            "total": len(hits),
            "actionable": len(actionable),
            "findings": hits,
        }, sys.stdout, indent=2, ensure_ascii=False)
        sys.stdout.write("\n")
        return 1 if actionable else 0

    if not hits:
        print("%s: clean (%d chars, no suspicious characters)"
              % (args.input, len(text)))
        return 0

    by_char = {}
    for h in hits:
        key = (h["char"], h["name"], h["action"], h["confidence"])
        by_char.setdefault(key, []).append(h)

    print("%s: %d finding(s), %d would be removed"
          % (args.input, len(hits), len(actionable)))
    print()
    width = max(len(k[1]) for k in by_char)
    for (code, nm, action, conf), group in sorted(
            by_char.items(), key=lambda kv: -len(kv[1])):
        where = ", ".join("%d:%d" % (h["line"], h["col"]) for h in group[:6])
        if len(group) > 6:
            where += ", +%d more" % (len(group) - 6)
        print("  %-9s %-*s  x%-4d %-7s %-16s %s"
              % (code, width, nm, len(group), action, conf, where))
    return 1 if actionable else 0


if __name__ == "__main__":
    sys.exit(main())
