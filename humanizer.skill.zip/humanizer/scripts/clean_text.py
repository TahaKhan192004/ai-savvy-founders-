#!/usr/bin/env python3
"""Remove invisible characters from text, leaving protected spans untouched.

    clean_text.py FILE -o OUT [--stats] [--format md|html|txt]
    clean_text.py FILE --in-place
    cat FILE | clean_text.py - > OUT

Defaults are conservative. Characters that carry layout or linguistic meaning
(unusual spaces, bidi controls, joiners doing real work, variation selectors)
are left alone and only reported. Code, markup, link targets, URLs, and YAML
frontmatter are never edited.

Exit status: 0 success, 2 usage error.
"""

import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import marks  # noqa: E402

NORMALIZE_SPACES = {ch: " " for ch in marks.SPACES}


def clean(text, fmt="auto", name="", aggressive_homoglyphs=False,
          normalize_spaces=False, strip_bidi=False):
    hits = marks.find_marks(text, fmt, name, aggressive_homoglyphs)
    removals = {}
    for h in hits:
        if h["protected"]:
            continue
        if h["action"] == "remove":
            removals[h["offset"]] = ""
        elif strip_bidi and h["class"] == "bidi":
            removals[h["offset"]] = ""
        elif normalize_spaces and h["class"] == "space":
            removals[h["offset"]] = " "

    if aggressive_homoglyphs:
        for h in hits:
            if h["class"] == "homoglyph" and not h["protected"]:
                removals[h["offset"]] = marks.HOMOGLYPHS[text[h["offset"]]]

    if not removals:
        return text, hits, {}

    out = []
    stats = {}
    for i, ch in enumerate(text):
        if i in removals:
            rep = removals[i]
            key = "U+%04X" % ord(ch)
            stats[key] = stats.get(key, 0) + 1
            if rep:
                out.append(rep)
        else:
            out.append(ch)
    return "".join(out), hits, stats


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("input")
    ap.add_argument("-o", "--output")
    ap.add_argument("--in-place", action="store_true")
    ap.add_argument("--stats", action="store_true")
    ap.add_argument("--format", default="auto",
                    choices=["auto", "md", "html", "txt"])
    ap.add_argument("--aggressive-homoglyphs", action="store_true",
                    help="also fold Cyrillic/Greek lookalikes to Latin")
    ap.add_argument("--normalize-spaces", action="store_true",
                    help="collapse NBSP and friends to a plain space")
    ap.add_argument("--strip-bidi", action="store_true",
                    help="also remove bidirectional control characters")
    args = ap.parse_args(argv)

    if args.in_place and args.output:
        print("--in-place and -o are mutually exclusive", file=sys.stderr)
        return 2
    if args.in_place and args.input == "-":
        print("--in-place needs a real file", file=sys.stderr)
        return 2

    try:
        if args.input == "-":
            text = sys.stdin.read()
        else:
            with open(args.input, "r", encoding="utf-8",
                      errors="surrogatepass") as fh:
                text = fh.read()
    except OSError as exc:
        print("cannot read %s: %s" % (args.input, exc), file=sys.stderr)
        return 2

    name = "" if args.input == "-" else args.input
    cleaned, hits, stats = clean(
        text, args.format, name,
        aggressive_homoglyphs=args.aggressive_homoglyphs,
        normalize_spaces=args.normalize_spaces,
        strip_bidi=args.strip_bidi)

    dest = args.input if args.in_place else args.output
    if dest:
        try:
            with open(dest, "w", encoding="utf-8",
                      errors="surrogatepass") as fh:
                fh.write(cleaned)
        except OSError as exc:
            print("cannot write %s: %s" % (dest, exc), file=sys.stderr)
            return 2
    else:
        sys.stdout.write(cleaned)

    if args.stats:
        total = sum(stats.values())
        left = [h for h in hits if h["action"] == "report"]
        msg = ["removed %d character(s)" % total]
        for code, n in sorted(stats.items(), key=lambda kv: -kv[1]):
            msg.append("  %s x%d" % (code, n))
        if left:
            msg.append("left in place (reported only): %d" % len(left))
            seen = {}
            for h in left:
                seen[(h["char"], h["name"], h["confidence"])] = \
                    seen.get((h["char"], h["name"], h["confidence"]), 0) + 1
            for (code, nm, conf), n in sorted(seen.items(),
                                              key=lambda kv: -kv[1]):
                msg.append("  %s %s x%d (%s)" % (code, nm, n, conf))
        print("\n".join(msg), file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
