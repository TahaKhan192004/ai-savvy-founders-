# Character hygiene and document metadata

Two deterministic passes that run alongside the prose rewrite. Both are about text that carries marks a reader cannot see. Neither is a rewrite, and neither has an opinion about style.

## Why this is separate from the rewrite

The rewrite is judgment. These passes are arithmetic: a character is either U+200B or it isn't. Keeping them apart matters for reporting, because you can state exactly what a deterministic pass did and you cannot state the same about a rewrite. See "Honest reporting" below.

## Layer A: invisible characters

`scripts/inspect_text.py` reports. `scripts/clean_text.py` removes. Both are pure Python 3 standard library, no install step, no network, no external service.

```bash
S=path/to/skills/humanizer/scripts
python3 "$S/inspect_text.py" draft.md              # look first
python3 "$S/clean_text.py" draft.md -o draft.clean.md --stats
python3 "$S/inspect_text.py" draft.clean.md        # confirm
```

Both accept `-` for stdin. Exit codes: 0 nothing actionable, 1 findings, 2 usage error. `--json` gives machine-readable output with line and column for every hit.

### What gets removed by default

Characters with no glyph and no layout role in Latin prose: zero-width space (U+200B), word joiner (U+2060), zero-width no-break space and BOM (U+FEFF), soft hyphen (U+00AD), Mongolian vowel separator (U+180E), and loose Unicode tag characters (U+E0000 to U+E007F).

Tag characters deserve their own note. They are a complete invisible ASCII alphabet. An arbitrary string can be encoded in them and pasted into any document, where it renders as absolutely nothing. That is the one class here that is almost never innocent.

### What gets reported but left alone

The script does not guess about characters that carry meaning:

- **Zero-width joiner and non-joiner** next to emoji, Arabic, Persian, or Indic text. Emoji sequences are built from ZWJ, and Persian and Hindi words are shaped by ZWNJ. Stripping these corrupts real words. A joiner in a run of plain Latin text is a different matter and is removed.
- **Tag characters inside a flag sequence.** The subdivision flags for England, Scotland, and Wales are U+1F3F4 followed by tag characters. Those are real; loose ones are not.
- **Variation selectors**, including U+FE0F, which is what makes an emoji render as an emoji.
- **Unusual spaces**: NBSP, narrow no-break space, figure space, thin space, ideographic space. These are visible and usually deliberate typography or CJK layout. `--normalize-spaces` collapses them if you want that.
- **Bidirectional controls.** Removing them silently can reorder how text displays. `--strip-bidi` opts in.
- **Cyrillic and Greek homoglyphs** sitting inside otherwise-Latin words, like a Cyrillic е in "response". Reported by default because real Cyrillic text obviously uses these letters. `--aggressive-homoglyphs` folds them to Latin.

### What is never touched

Fenced and inline code, HTML `<code>`, `<pre>`, `<script>` and `<style>` blocks, every HTML tag and attribute, Markdown link targets, URLs, and YAML frontmatter. A zero-width space inside a code fence stays there, because removing it could change what the code does.

This is the same protected-span rule as Rule 3 in SKILL.md, applied mechanically.

## Document metadata

`scripts/scan_doc_metadata.py` reports and optionally clears authoring fields in text documents.

```bash
python3 "$S/scan_doc_metadata.py" post.md
python3 "$S/scan_doc_metadata.py" post.md --strip -o post.clean.md
python3 "$S/scan_doc_metadata.py" report.docx --json
```

Covers YAML frontmatter keys (`generator`, `author`, `model`, `created_with`, and similar), HTML `<meta name="generator">` and `<meta name="author">` tags plus generator comments, and the package properties inside DOCX, ODT, PPTX, XLSX and EPUB (`dc:creator`, `cp:lastModifiedBy`, `Application`, `Company`).

Body text is never modified. For packages, the output is a rebuilt archive with the named fields emptied and every other part copied through byte for byte.

Stripping author metadata from a document you are about to publish is ordinary practice, the same reason people check a PDF's properties before sending it. Do not strip metadata from a document that someone else needs for attribution, provenance, or a records requirement.

## Out of scope

This skill does not touch binary media. Specifically not covered:

- **EXIF, IPTC, and XMP** in images. Use `exiftool`.
- **C2PA Content Credentials** in images, video, or PDF. Use `c2patool`. These are cryptographically signed provenance manifests, and a C2PA soft binding can survive metadata stripping entirely.
- **PDF document information dictionaries and XMP.** Use `exiftool` and `qpdf`.
- **Pixel-domain and audio watermarks**, including SynthID-class marks. Removing those needs heavy model-based tooling and is a different problem from anything here.
- **Token-sampling watermarks.** A rewrite disturbs them; nothing in Layer A touches them at all.

If you need any of these, say so plainly and point at the right tool. Do not imply the scripts here did something they did not.

## Honest reporting

When you report what a pass accomplished, separate three tiers and never blur them:

**Verifiable.** The deterministic passes. "Removed 4 zero-width spaces and 3 tag characters; cleared `generator` and `author` from the frontmatter." Exact counts, backed by a re-inspection that comes back clean.

**Best effort.** The prose rewrite. It changes token and syntax patterns. That is all you can say about it. Residual signal is lower in short, predictable text and higher in long, high-entropy prose.

**Not established.** Everything else. A rewrite does not prove human authorship, does not defeat a vendor's secret-key detector, and is not "undetectable." Do not say or imply otherwise, and do not let a summary drift into implying it.

That last tier is why the skill dropped the claim it used to carry about passing detectors. It was not true, and stating it made the rest of the report less trustworthy.
