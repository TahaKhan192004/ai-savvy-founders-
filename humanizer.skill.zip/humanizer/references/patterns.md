# Pattern catalog

Thirty-six patterns, grouped. Each entry names what to look for, why it reads as machine-written, and shows a rewrite.

Two reminders before you use any of them. Rule 1 in SKILL.md: the rewrite keeps every claim the source made. Rule 3: anything quoted, titled, named, or under discussion rather than in use stays untouched.

---

## Content

### 1. Inflated importance and legacy

**Watch for:** stands as, serves as, is a testament to, a vital/crucial/pivotal role, underscores its significance, reflects broader, symbolizing its enduring, setting the stage for, marks a shift, key turning point, evolving landscape, indelible mark, deeply rooted

**Problem:** An ordinary detail gets described as a major turning point, proof of a legacy, or evidence of a wider trend.

Before:
> The Statistical Institute of Catalonia was officially established in 1989, marking a pivotal moment in the evolution of regional statistics in Spain. This initiative was part of a broader movement across Spain to decentralize administrative functions and enhance regional governance.

After:
> The Statistical Institute of Catalonia was established in 1989, part of a wider decentralization of administrative functions in Spain.

### 2. Name-dropping to prove importance

**Watch for:** independent coverage, local and national media outlets, written by a leading expert, active social media presence, follower counts

**Problem:** A list of well-known publications or a follower number stands in for saying why the subject matters. The list carries no information.

Before:
> Her views have been cited in The New York Times, BBC, Financial Times, and The Hindu. She maintains an active social media presence with over 500,000 followers.

After:
> Her views have been cited in The New York Times and the BBC.

Where the source says what the person actually argued and where, keep it. That is a useful citation, not name-dropping. Never invent the context to justify keeping the name.

### 3. Shallow analysis in a trailing -ing phrase

**Watch for:** highlighting..., underscoring..., emphasizing..., ensuring..., reflecting..., symbolizing..., contributing to..., fostering..., encompassing..., showcasing...

**Problem:** A present-participle clause gets bolted onto a plain fact to make it sound analyzed. It almost never adds information.

Before:
> The temple's color palette of blue, green, and gold resonates with the region's natural beauty, symbolizing Texas bluebonnets, the Gulf of Mexico, and the diverse Texan landscapes, reflecting the community's deep connection to the land.

After:
> The temple is painted blue, green, and gold, colors meant to evoke Texas bluebonnets and the Gulf of Mexico.

Before:
> The company opened a new office in Berlin, underscoring its commitment to European expansion.

After:
> The company opened a new office in Berlin as part of its European expansion.

### 4. Sales language

**Watch for:** boasts a, vibrant, rich (figurative), profound, enhancing its, showcasing, exemplifies, commitment to, natural beauty, nestled, in the heart of, groundbreaking, renowned, breathtaking, must-visit, stunning

**Problem:** Descriptions of places, culture, products, and organizations drift into advertising register.

Before:
> Nestled within the breathtaking region of Gonder in Ethiopia, Alamata Raya Kobo stands as a vibrant town with a rich cultural heritage and stunning natural beauty.

After:
> Alamata Raya Kobo is a town in the Gonder region of Ethiopia.

### 5. Vague sources

**Watch for:** industry reports, observers have noted, experts argue, some critics argue, several sources indicate, studies show

**Problem:** A claim gets assigned to unnamed experts, critics, reports, or observers, which makes it unfalsifiable.

Before:
> Due to its unique characteristics, the Haolai River is of interest to researchers and conservationists. Experts believe it plays a crucial role in the regional ecosystem.

After:
> Researchers and conservationists study the Haolai River for its unusual characteristics.

Name the real source when the source text gives one. Otherwise drop the claim. Never invent an attribution, and never write "multiple studies show" when you have one study or none.

### 6. Formulaic challenges and outlook

**Watch for:** Despite its... faces several challenges, Despite these challenges, Challenges and Legacy, Future Outlook

**Problem:** A stock section about difficulties and future prospects gets appended regardless of whether there is anything to say. It restates vague claims instead of adding facts.

Before:
> Despite its industrial prosperity, Korattur faces challenges typical of urban areas, including traffic congestion and water scarcity. Despite these challenges, with its strategic location and ongoing initiatives, Korattur continues to thrive as an integral part of Chennai's growth.

After:
> Korattur has recurring traffic congestion and water shortages.

Add dates or specific actions only when the source provides them.

---

## Grammar and sentence construction

### 7. Copula avoidance

**Watch for:** serves as, stands as, functions as, represents, marks, boasts, features, offers

**Problem:** Simple verbs get replaced with longer phrases. After vocabulary clustering, this is the strongest single tell. Write "is" and "has" freely.

Before:
> Gallery 825 serves as LAAA's exhibition space for contemporary art. The gallery features four separate spaces and boasts over 3,000 square feet.

After:
> Gallery 825 is LAAA's exhibition space for contemporary art. It has four rooms totaling 3,000 square feet.

Before:
> The app features an intuitive dashboard that offers real-time analytics.

After:
> The app has a dashboard with real-time analytics.

### 8. Not X but Y, and clipped negative endings

**Problem:** "Not only... but also," "It's not just X, it's Y," and their variants are TED-talk cadence, not speech. A related habit tacks a clipped negative onto the end of a sentence instead of writing the clause out.

Before:
> It's not just about the beat riding under the vocals; it's part of the aggression and atmosphere. It's not merely a song, it's a statement.

After:
> The heavy beat adds to the aggressive tone.

Before:
> It's not just a tool; it's a movement.

After:
> It started as a tool and turned into something bigger.

Before:
> The options come from the selected item, no guessing.

After:
> The options come from the selected item, so the user never has to guess.

### 9. Forced groups of three (the rule of three)

**Problem:** Ideas get padded into triples to sound complete, with the third item carrying no weight.

Before:
> The event features keynote sessions, panel discussions, and networking opportunities. Attendees can expect innovation, inspiration, and industry insights.

After:
> The event includes keynote sessions, panel discussions, and time to network between them.

The first triple survives because all three items are real. The second is cut because none of the three says anything.

This pattern is where Rule 1 gets broken most often. "The platform is fast, reliable, and user-friendly" is three separate claims. Trimming it to "the platform is fast" deletes two of them. If all three are real, keep all three and fix the rhythm instead. Cut only the items that carry no information.

### 10. Synonym cycling and repeated openings

**Problem:** Repetition gets handled by rule rather than by ear. The same subject gets renamed every sentence, or several sentences in a row open with the same word.

Before:
> The protagonist faces many challenges. The main character must overcome obstacles. The central figure eventually triumphs. The hero returns home.

After:
> The protagonist faces many challenges but eventually triumphs and returns home.

Before:
> She noted the door. She noted the lock on it. She filed both away.

After:
> She noted the door and its lock, then filed both away.

Use one name for one subject. For repeated openings, merge the sentences, change the subject, or lead with the action. Do not ban the word itself; the fixed version may still start with "She."

### 11. False from X to Y ranges

**Problem:** "From X to Y" implies a spectrum where none exists.

Before:
> Our journey through the universe has taken us from the singularity of the Big Bang to the grand cosmic web, from the birth and death of stars to the enigmatic dance of dark matter.

After:
> The book covers the Big Bang, star formation, and current theories about dark matter.

### 12. Passive voice and missing subjects

**Problem:** The actor gets hidden or the subject dropped entirely. Use active voice where it makes who does what clearer.

Before:
> No configuration file needed. The results are preserved automatically.

After:
> You do not need a configuration file. The system preserves the results automatically.

Passive voice is not always wrong. Use it when the actor is genuinely unknown or genuinely irrelevant.

### 13. Monotone rhythm

**Problem:** Every sentence lands at roughly the same length and the same shape. This survives every vocabulary fix and is often what still reads as machine-written after the obvious tells are gone.

Fix it by mixing lengths. Let a short sentence follow a long one. Start some sentences with "But," "And," "So," or "Still." Use a fragment occasionally. Read the paragraph aloud; if it has no variation in pace, rewrite it rather than reword it.

---

## Style and formatting

### 14. Em and en dashes

**Rule:** The rewrite ships without em dashes, en dashes used as dashes, spaced hyphens, or double hyphens. Replace each with a period, comma, colon, or parentheses, or rewrite the sentence. Two overrides: the writer's sample uses them, or the user asks to keep them.

Before:
> The term is primarily promoted by Dutch institutions—not by the people themselves. You don't say "Netherlands, Europe" as an address—yet this mislabeling continues—even in official documents.

After:
> The term is primarily promoted by Dutch institutions, not by the people themselves. You don't say "Netherlands, Europe" as an address, yet this mislabeling continues in official documents.

Before:
> The new policy — announced without warning — affects thousands of workers. The changes -- long overdue according to critics -- will take effect immediately.

After:
> The new policy, announced without warning, affects thousands of workers. The changes, long overdue according to critics, will take effect immediately.

Before returning the rewrite, search the text for `—` and `–`, and for ` -- ` and ` - ` used as dashes.

This is an output preference. A dash in someone's draft is not evidence that a machine wrote it. See "What not to flag" in SKILL.md.

### 15. Too much bold

**Problem:** Words and phrases get bolded in running prose with no clear reason.

Before:
> It blends **OKRs (Objectives and Key Results)**, **KPIs (Key Performance Indicators)**, and visual strategy tools such as the **Business Model Canvas (BMC)** and **Balanced Scorecard (BSC)**.

After:
> It blends OKRs, KPIs, and visual strategy tools like the Business Model Canvas and Balanced Scorecard.

Bold belongs on headings, labels, and UI element names. Not on emphasis in prose.

### 16. Inline-header bullet lists

**Problem:** Every list item opens with a bold label and a colon, whether or not the content is definitional.

Before:
> - **User Experience:** The user experience has been significantly improved with a new interface.
> - **Performance:** Performance has been enhanced through optimized algorithms.
> - **Security:** Security has been strengthened with end-to-end encryption.

After:
> The update improves the interface, speeds up load times through optimized algorithms, and adds end-to-end encryption.

The carve-out: a genuine definition list, glossary, or structured reference entry where each item defines its lead term. That is what the format is for. The tell is using it for everything, including prose that should have stayed prose.

### 17. Title case in headings

Before:
> ## Strategic Negotiations And Global Partnerships

After:
> ## Strategic negotiations and global partnerships

Sentence case by default. Use title case when the publication's style guide calls for it.

### 18. Emoji as decoration

Before:
> 🚀 **Launch Phase:** The product launches in Q3
> 💡 **Key Insight:** Users prefer simplicity
> ✅ **Next Steps:** Schedule follow-up meeting

After:
> The product launches in Q3. User research showed a preference for simplicity. Next step: schedule a follow-up meeting.

Social posts and casual chat are different contexts. Judge by where the text is going.

### 19. Curly quotation marks

**Problem:** Curly quotes appear where the writer or the target format uses straight ones.

Before:
> He said “the project is on track” but others disagreed.

After:
> He said "the project is on track" but others disagreed.

Low-signal on its own. Word, Google Docs, and macOS all curl quotes automatically. Fix it to match the destination format, not as evidence of anything.

### 20. Markdown in non-Markdown contexts

**Problem:** Asterisks and hash marks end up in email bodies, SMS, plain-text fields, and chat clients that do not render them, where they show up as literal characters.

Before (in an email body):
> ## Next steps
> **Action required:** please review the attached by Friday.

After:
> Next steps
>
> Action required: please review the attached by Friday.

Check where the text is going before formatting it.

---

## Chatbot residue

### 21. Assistant text left in the answer

**Watch for:** I hope this helps, Of course!, Certainly!, You're absolutely right, Would you like..., Want me to...?, Should I continue?, let me know, here is a...

**Problem:** A greeting, offer, or closing survives into text that has to stand on its own.

Before:
> Here is an overview of the French Revolution. I hope this helps! Let me know if you'd like me to expand on any section.

After:
> The French Revolution began in 1789 when financial crisis and food shortages led to widespread unrest.

### 22. Knowledge-limit disclaimers and speculative gap-fill

**Watch for:** as of [date], up to my last training update, while specific details are limited, based on available information, not publicly available, maintains a low profile, keeps personal details private, likely grew up, it is believed that

**Problem:** The text notes that a source could not be found, then fills the gap with a plausible guess presented as fact.

Before:
> While specific details about the company's founding are not extensively documented in readily available sources, it appears to have been established sometime in the 1990s.

After:
> The company's founding date is not documented in the available sources.

Before:
> Information about her early life is not publicly available, suggesting she maintains a low profile and keeps personal details private. She likely grew up in a middle-class household, which shaped her later interest in education reform.

After:
> Her early life is not documented in the available sources.

Either state what the source does not show, or cut the sentence. Never present the guess.

### 23. Overly agreeable tone

**Problem:** The answer opens by praising the question or agreeing with the reader.

Before:
> Great question! You're absolutely right that this is a complex topic. That's an excellent point about the economic factors.

After:
> The economic factors you mentioned are relevant here.

---

## Rhetoric

### 24. Pretending to reveal a deeper truth

**Watch for:** the real question is, at its core, in reality, what really matters, fundamentally, the deeper issue, the heart of the matter

Before:
> The real question is whether teams can adapt. At its core, what really matters is organizational readiness.

After:
> The question is whether teams can adapt. That mostly depends on whether the organization is ready to change its habits.

### 25. Announcing the next point

**Watch for:** let's dive in, let's explore, let's break this down, here's what you need to know, now let's look at, without further ado, heads up, quick note, before I forget

**Problem:** The text announces what it is about to say instead of saying it. This happens in casual register too, so remove the announcement rather than just its formality.

Before:
> Let's dive into how caching works in Next.js. Here's what you need to know.

After:
> Next.js caches data at multiple layers, including request memoization, the data cache, and the router cache.

Before:
> One thing that bit me hard, so pay attention to this part: the webpack dev server doesn't send the CORS header by default.

After:
> The webpack dev server doesn't send the CORS header by default.

### 26. Forced punchlines and dramatic fragments

**Problem:** Every sentence tries to be a closing line. One short sentence adds emphasis. A row of them reads as staged.

Before:
> Then AlphaEvolve arrived. It had no preference for symmetry. No aesthetic prior. No nostalgia for human taste. The old rules were gone.

After:
> AlphaEvolve changed the search because it did not favor symmetry or human-looking designs. That made some of the older assumptions less useful.

### 27. Formulaic sayings

**Watch for:** X is the Y of Z, X becomes a trap, X is not a tool but a mirror, the language of, the currency of, the architecture of

**Problem:** An ordinary claim gets restated as an aphorism that sounds profound and says less than the original.

Before:
> Symmetry is the language of trust. Efficiency becomes a trap when teams forget the human layer.

After:
> Symmetric layouts often feel more predictable to users. Teams can over-optimize a workflow and lose track of how people actually use it.

### 28. Fake-candid openings

**Watch for:** Honestly?, Look, Here's the thing, The thing is, Let's be honest, Real talk, used as standalone hooks

**Problem:** A staged pause or a claim of honesty precedes an entirely routine point.

Before:
> Is it worth the price? Honestly? It depends on how often you'll use it.

After:
> Whether it's worth the price depends on how often you'll use it.

"Honestly" and "look" mid-sentence are ordinary casual speech. The tell is the theatrical standalone opener.

### 29. Answering objections no one raised

**Watch for:** This isn't really about, I'm not saying, To be clear, Don't get me wrong, This is not to say, You could argue this differently but, Some might say... but

**Problem:** The text defends against an objection that appears nowhere, often a leftover from an earlier draft.

Before:
> This isn't mainly about prompt length, and I'm not arguing that documentation doesn't matter. You could categorize the problem another way, but the issue is whether the agent can use the instruction when it acts.

After:
> The issue is whether the agent can use the instruction when it acts.

Remove only the undefended defense. If it contains a real claim, state that claim directly. Keep an objection that names its source or gets a full answer. A plain statement like "the API is not thread-safe" is not this pattern.

### 30. Rejecting fake alternatives

**Watch for:** a tempting approach would be, one might be tempted to, an obvious approach would be, you might think... but, it would be easy to just, some would suggest

**Problem:** An option no reader would consider gets introduced, dismissed in a clause, and never mentioned again.

Before:
> Session tokens are rotated every 24 hours. A tempting approach would be to rotate them by restarting the auth service on a cron job, but that would drop every active session. Rotation happens in place, and clients refresh transparently.

After:
> Session tokens are rotated every 24 hours, in place, and clients refresh transparently.

One rejected option can be legitimate. Several short unrelated rejections is the stronger signal. Ask what each adds. If it only records a decision someone already made, rewrite the paragraph around its actual point. Keep real alternatives a reader would weigh in a design document or tutorial.

### 31. Generic positive endings

**Problem:** The piece closes on vague optimism instead of its last useful fact.

Before:
> The future looks bright for the company. Exciting times lie ahead as they continue their journey toward excellence. This represents a major step in the right direction.

After:
> Cut the paragraph and end on the last concrete fact. If the source states real plans, use those.

---

## Structure

### 32. Rigid outline articles

**Problem:** Content gets forced into a standard skeleton regardless of subject: Introduction, History, Features, Awards and Recognition, Challenges, Future Outlook.

Write the structure the content needs. A short subject gets a short piece. If a section exists only because the template has that section, delete it.

### 33. Dictionary-definition leads

**Problem:** The opening sentence defines the title as though the reader looked it up, delaying the actual news.

Before:
> Kubernetes is an open-source container orchestration platform. It was originally developed by Google. In March, the project announced it would deprecate Dockershim.

After:
> The Kubernetes project announced in March that it will deprecate Dockershim, the shim that lets the platform run Docker as a container runtime.

Lead with the most important fact.

### 34. Summary and conclusion sections

**Problem:** A closing section restates what the piece already said, under a heading like "Conclusion," "In summary," or "Key takeaways."

End when the content ends. A real summary is fine where the format calls for one, such as an abstract, an executive summary, or a long report. Adding one to a 600-word post is filler.

### 35. A heading repeated in the first sentence

**Problem:** A heading is followed by a one-line paragraph that only restates the heading.

Before:
> ## Performance
>
> Speed matters.
>
> When users hit a slow page, they leave.

After:
> ## Performance
>
> When users hit a slow page, they leave.

### 36. Writing about the previous version

**Problem:** Documentation and code comments describe what changed rather than what is true now.

Before:
> This function was added to replace the previous approach of iterating through all items, which caused O(n²) performance.

After:
> This function uses a hash map for O(1) lookups, avoiding the O(n²) cost of naive iteration.

Change logs, release notes, and migration guides are about change. Everything else describes current behavior.
