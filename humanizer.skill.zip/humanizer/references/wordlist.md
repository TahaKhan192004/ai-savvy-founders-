# Vocabulary reference

Rule 3 in SKILL.md overrides everything here: a word inside a quotation, title, proper name, or a phrase being discussed rather than used stays exactly as written. Rule 4 also overrides: if the writer's own sample uses a word on these lists, keep it.

These lists name words that AI writing overuses. They are not a claim that the words are bad. One "crucial" in a long document is invisible. Three in a paragraph is the single strongest tell there is.

## Hard ban

No drop-in replacement exists for these. Rewrite the sentence around the idea instead.

| Phrase | Why |
|---|---|
| delve, deep dive | The signature word. Almost never used this way in ordinary writing. |
| tapestry, interplay (abstract nouns) | Decorative abstraction standing in for a specific relationship. |
| indelible mark | Pure puffery. Nothing measurable is being claimed. |
| landscape (abstract noun) | "The evolving landscape of X" means "X". |
| in the heart of, nestled | Travel-brochure register applied to ordinary geography. |
| is a testament to | Asserts significance without evidence. |
| it's important / crucial / critical to note | Announces the next sentence instead of writing it. |
| not just X, but also Y | The cliché parallelism. Say the thing directly. |
| setting the stage for | Retroactive narrative imposed on a plain fact. |
| focal point (meaning "focus") | Longer synonym for a short word. |
| a testament to its enduring legacy | Two tells in one phrase. |

## Soft ban

Use the plain synonym. If none of them fits, the sentence probably needs rewriting.

| Avoid | Prefer |
|---|---|
| actually (as filler) | cut it |
| additionally (sentence-initial) | also, and, on top of that, beyond that |
| align with, resonate with | match, fit, connect with |
| boasts (meaning "has") | has, includes, offers |
| bolstered | strengthened, supported |
| commitment to | focus on, dedication to |
| crucial, pivotal, vital (generic emphasis) | important, key, central, big |
| diverse array | range, mix, variety |
| encompasses | includes, covers, spans |
| enhance, enhancing | improve, strengthen, lift |
| exemplifies | shows, illustrates, represents |
| foster, fostering | build, encourage, grow |
| garner | earn, attract, get, win |
| groundbreaking (figurative) | new, original, first of its kind |
| highlight, underscore (verbs meaning "show") | show, reveal, point to, make clear |
| intricate, intricacies | complex, detailed, nuanced |
| key (as a stock adjective) | main, central, or cut it |
| meticulous, meticulously | careful, precise, thorough |
| quietly (as in "quietly became") | cut it |
| reflects broader | connects to wider, ties into larger |
| renowned | well known, respected, famous |
| represents a shift | marks a change, is a change |
| robust | strong, solid, reliable |
| serves as, stands as, functions as | is |
| showcase, showcasing | show, display, feature, demonstrate |
| valuable insights | useful findings, helpful takeaways |
| vibrant | lively, energetic, colorful |

Preserve established technical usage. "Gated release," "robust error handling," and "key" in cryptography are terms of art, not tells.

## Era-specific tells

These phrases fingerprint particular model generations. They read as dated as well as artificial.

- "key turning point," "evolving landscape," "enduring legacy," "rich cultural heritage"
- "active social media presence," "independent coverage," "trade publications," "leading expert in the field"
- "maintains a low profile," "keeps personal details private," "prefers to stay out of the spotlight"
- "in today's fast-paced world," "in an era of," "now more than ever"

## Filler phrases

Direct substitutions. These are almost always safe.

| Instead of | Write |
|---|---|
| in order to achieve this goal | to achieve this |
| due to the fact that | because |
| at this point in time | now |
| in the event that you need help | if you need help |
| has the ability to process | can process |
| it is important to note that the data shows | the data shows |
| for the purpose of | to, for |
| in spite of the fact that | although |
| a large number of | many |
| at the present time | now |
| in the near future | soon |

## Stacked qualifiers

Repeated editing piles caveat on caveat until nothing is being claimed. Watch for: to be fair, it's also possible, could potentially, might arguably, in some cases it may, this is an inference, it could be argued.

Keep a qualifier when the source supports it and the meaning needs it. Cut the ones that only patch an earlier overstatement.

Before: It could potentially possibly be argued that the policy might have some effect on outcomes.

After: The policy may affect outcomes.

## Hyphenated pairs

AI writing hyphenates these everywhere: third-party, cross-functional, client-facing, data-driven, decision-making, well-known, high-quality, real-time, long-term, end-to-end.

Keep the hyphen when the pair sits before the noun it modifies: `a high-quality report`.

After the noun, follow the document's existing convention. If it has none, Chicago drops the hyphen: `the report is high quality`. This one is a house-style call, not a rule. Do not churn a document that has already picked a side.
