---
name: humanizer
description: >
  Rewrite AI-sounding text so it reads like a person wrote it, without changing what it says,
  and clean the marks a reader cannot see. Use when asked to humanize, de-AI, or strip AI tone
  from a draft; when asked to edit, polish, or proofread prose carrying inflated claims, sales
  language, vague sources, stock AI vocabulary, formulaic structure, or leftover chatbot
  artifacts; when reviewing whether a piece of writing reads as machine-generated; or when
  asked to strip invisible Unicode, zero-width characters, or generator and author metadata
  from a document. Invoke this skill explicitly. It does not auto-apply to every writing task,
  and it yields to a brand-voice skill already handling the same text.
license: MIT
metadata:
  version: "3.1.0"
---

# Humanizer

Rewrite AI-sounding text so it reads like the writer, not a chatbot.

The pattern catalog comes from Wikipedia's ["Signs of AI writing"](https://en.wikipedia.org/wiki/Wikipedia:Signs_of_AI_writing), maintained by WikiProject AI Cleanup, extended with vocabulary and structural rules gathered from editing practice.

## Four rules that never bend

Everything else in this skill is a style preference. These four are correctness.

**1. Keep every claim.** You may shorten dull passages, expand useful ones, merge paragraphs, split them, or reorder them. You may not drop a fact, a name, a number, a date, a caveat, or a qualifier the source depended on. "The platform is fast, reliable, and user-friendly" has three claims in it. Cutting it to "the platform is fast" is not a style fix, it is a content change, and it is the most common way this kind of rewrite goes wrong.

**2. Invent nothing.** Do not add a fact, name, number, date, quote, citation, or source that did not come from the source text or the user. If a sentence needs a detail you do not have, ask for it or write a simpler sentence. You may add an opinion, a reaction, or an aside when the writer's voice calls for one. You may not add a factual claim. Fiction is exempt, since invented detail is the job there.

**3. Never rewrite borrowed or non-prose text.** Leave these exactly as they are:

quotations, titles, proper names, brand names, headline text, and any phrase being discussed rather than used; fenced and inline code; commands, file paths, URLs, identifiers, API names, and exact values; formulas, citations, and required legal, academic, or platform disclosures.

A banned word inside a direct quote stays in the quote. This holds whether or not the user asks for it. The deterministic passes below enforce the same list mechanically.

**4. A writing sample beats every rule below.** If the user supplies their own previous writing, that sample defines the target voice. Read it before you rewrite. Match its sentence length, vocabulary level, paragraph openings, punctuation habits, and transitions. If the sample uses em dashes, keep them at roughly the sample's rate. If it uses a word this skill discourages, keep it. Do not sand off a deliberate quirk.

## How this composes with other skills

This skill owns AI-tell removal. It does not own voice, brand, or platform format.

If a brand-voice or platform skill is already handling the text, that skill wins on tone, structure, vocabulary, and calls to action. Apply only the four rules above plus the catalog checks that do not contradict it. Do not run both rule sets at full strength and hope for the best.

If nothing else is handling the text, run the whole skill.

## Workflow

1. **Read the source once, straight through.** If a writing sample was supplied, read that first and note its habits.
2. **Mark the patterns.** Check against `references/patterns.md` (the catalog) and `references/wordlist.md` (vocabulary). Read those files now if you have not already; do not work from memory of what AI writing sounds like.
3. **Rewrite by paragraph, not by phrase.** Patching each flagged phrase in place leaves the underlying rhythm intact, which is what actually reads as machine-written. Take the paragraph's point and state it again in the target voice.
4. **Run the self-check** below.
5. **Run the deterministic passes** when the text is going to or coming from a file. Character hygiene always; document metadata when the format carries it.
6. **Return the result** in the mode the request calls for, reporting each tier honestly.

## Character hygiene

AI output routinely carries characters a reader never sees: zero-width spaces, word joiners, soft hyphens, stray BOMs, and Unicode tag characters, which are a complete invisible ASCII alphabet that renders as nothing at all. These survive copy and paste, and no amount of rewriting touches them.

Two scripts handle it. Standard library Python 3, no install, no network, no service to start.

```bash
S=path/to/skills/humanizer/scripts
python3 "$S/inspect_text.py" draft.md                        # look first
python3 "$S/clean_text.py" draft.md -o draft.clean.md --stats
python3 "$S/inspect_text.py" draft.clean.md                  # confirm
```

Defaults are conservative, and deliberately so. Removed: characters with no glyph and no layout role. Reported but left alone: joiners doing real work in emoji, Arabic, Persian, or Indic text; tag characters inside a flag sequence; variation selectors; unusual spaces; bidi controls; Cyrillic and Greek homoglyphs. Opt in with `--normalize-spaces`, `--strip-bidi`, or `--aggressive-homoglyphs` only when the user asks and the text is Latin-script.

Code, markup, link targets, URLs, and frontmatter are never edited. That is Rule 3, applied mechanically.

Use `-` for stdin, `--json` for machine output. Exit 0 clean, 1 findings, 2 usage error. Write to `*.clean.*` unless the user asks for in-place.

For text you are returning in chat rather than writing to a file, do the rewrite and say so. Do not claim a deterministic pass ran when it did not.

## Document metadata

Markdown frontmatter, HTML head tags, and DOCX or ODT package properties can name the tool and the author.

```bash
python3 "$S/scan_doc_metadata.py" post.md
python3 "$S/scan_doc_metadata.py" post.md --strip -o post.clean.md
```

Body text is never modified; only the reported fields are cleared. Packages are rebuilt with every other part copied through unchanged.

This covers text documents only. EXIF, XMP, C2PA Content Credentials, PDF metadata, and pixel or audio watermarks are out of scope and need `exiftool`, `c2patool`, or `qpdf`. Say so plainly rather than implying these scripts did more than they did.

Details and the full character tables: `references/provenance.md`.

## Honest reporting

Three tiers. Never blur them.

**Verifiable.** What the deterministic passes did, with counts, confirmed by a clean re-inspection. "Removed 4 zero-width spaces and 3 tag characters; cleared `generator` from the frontmatter."

**Best effort.** The rewrite. It changes token and syntax patterns. Residual signal is lower in short, predictable text and higher in long, high-entropy prose.

**Not established.** Everything else. A rewrite does not prove human authorship, does not defeat a vendor's secret-key detector, and is not undetectable. Never say or imply it is, in the summary or anywhere else.

## Output modes

**Default (text pasted into the conversation).** Return the finished rewrite, then a short list of what changed, grouped by pattern. Two to five bullets. Do not reprint the original and do not show an intermediate draft.

**File mode (the user names a file).** Write only the final text to the file. Change prose only: leave code blocks, YAML frontmatter, data tables, link targets, and image paths untouched. Then summarize the changes in the conversation.

**Embedded mode (another task calls this skill for a commit message, PR body, email, or document).** Return the final text only. No change list, no commentary.

**Review mode (the user asks what is wrong rather than for a fix).** List the patterns you found with line or quote references and a suggested replacement for each. Do not rewrite the whole piece.

## Personality

Removing AI patterns is half the job. What is left should still sound like someone.

Add personality to blog posts, essays, opinion pieces, social content, and personal writing, when it fits the writer. Keep reference documentation, technical writing, legal text, and factual summaries neutral. Do not add opinions or first-person voice where they do not belong.

Where personality fits, protect the writer's opinions, uncertainty, mixed feelings, humor, asides, and uneven rhythm. Rule 2 still holds: never invent a fact to make a passage feel personal.

## Register

Match the register of the context, not a default professional polish. A Slack message stays a Slack message. A text to a friend stays casual. A board memo stays formal. If the user writes to you casually, write back casually.

## What human writing does

Removing tells is subtractive. These are the patterns to write toward:

- Plain "is," "are," and "has."
- Hedges where the writer is actually unsure: maybe, probably, tends to, often, it seems like.
- Flat superlatives where they are earned: one of the best, the first, the only.
- Colloquial connectors: but, so, though, still, anyway.
- Concrete specifics instead of abstractions.
- Opinions stated plainly. "This is a strong option," not "this option is widely regarded as robust."
- Some unevenness. A sentence that runs long, an aside, an occasional fragment.

The last one is where Rule 2 gets tested. An aside, a reaction, or a hedge is yours to add. A fact, a number, or a name is not.

## The pattern catalog

Full catalog with before and after examples: `references/patterns.md`. Vocabulary tables: `references/wordlist.md`. Character tables and the scope limits of the deterministic passes: `references/provenance.md`.

The catalog covers eight groups:

- Content: inflated importance, name-dropping, shallow -ing analysis, sales language, vague sources, formulaic challenge and outlook sections
- Vocabulary: overused AI words, era-specific model tells
- Grammar: copula avoidance, negative parallelism, forced triples, synonym cycling, false ranges, passive voice, monotone rhythm
- Style: dashes, bold, inline-header lists, title case, emoji, curly quotes
- Chatbot residue: greetings and sign-offs, knowledge-cutoff disclaimers, speculative gap-filling, flattery
- Filler: stock phrases, stacked qualifiers, generic positive endings, hyphen overuse
- Rhetoric: false depth, announced transitions, forced punchlines, formulaic sayings, fake candor, unraised objections, rejected fake alternatives
- Structure: rigid outlines, dictionary-definition leads, summary sections, heading echo, markdown in plain-text contexts

## The five deadliest tells

If you check nothing else, check these:

1. Vocabulary clusters. Three or more stock AI words in one paragraph.
2. "Serves as" and "represents" where "is" works.
3. Trailing -ing clauses that editorialize. "..., underscoring its commitment to X."
4. Filler paragraphs about legacy, significance, or broader trends.
5. Inline-header bold bullet lists used for everything.

## Self-check before returning

Run these in order. The first one is the only one that can make the rewrite wrong rather than merely imperfect.

1. Compare the rewrite against the source claim by claim. Did anything get dropped, added, softened, or strengthened? Anything you cannot trace to the source is an error, not a style choice.
2. Did any quotation, title, proper name, or code block get rewritten? Restore it.
3. Are there three or more discouraged words in the same paragraph? Rewrite the paragraph.
4. Did "serves as," "represents," "functions as," or "stands as" survive where "is" would do?
5. Count the trailing -ing clauses. More than one per 300 words is too many.
6. Does any sentence exist only to assert that something matters? Cut it.
7. Is anything attributed to unnamed experts, critics, observers, or reports? Name the source or cut the claim.
8. Are there filler triples where only one or two items carry weight? Keep the ones that mean something; do not delete a real claim to hit the target.
9. Search the output for the characters `—` and `–`, plus spaced hyphens and double hyphens used as dashes. Remove them unless the writing sample uses them.
10. Read it aloud. Does the sentence length vary? If every sentence is the same mid-length shape, the vocabulary fixes will not save it.
11. For file output, run `inspect_text.py` on the result. It should come back clean, or report only characters you deliberately kept.
12. Check the summary against the three reporting tiers. Anything stated as fact must come from a deterministic pass.

## What not to flag

A person can write any of these. None of them is evidence by itself:

- **Clean grammar and consistent style.** Plenty of writers are professionals or have been edited. Polish is not proof.
- **Mixed casual and formal register.** Often a reflection of field, age, or habit.
- **Dry, plain prose.** AI writing has specific tells. Dryness without them is just dry writing.
- **Formal vocabulary.** The wordlist names specific overused words. It is not a mandate to simplify every formal word.
- **A salutation or a sign-off.** These predate chatbots by centuries.
- **One transition word.** "Additionally," "moreover," and "consequently" read as AI only when stacked. A single "however" is nothing.
- **Curly quotes.** macOS, Word, Google Docs, and most CMSes curl quotes automatically.
- **Em dashes.** Many editors and journalists use them heavily. Removing them from the output is a house-style default, explained below. It is not a detection signal, and you should never cite a dash as evidence that something was AI-written.
- **One short sentence for emphasis.** Flag dramatic fragments only when several run together.
- **Deliberate repeated openings.** "She came. She saw. She conquered." is rhythm, not a defect. Change it only when the repetition does nothing.
- **"Honestly" or "look" mid-sentence.** Ordinary in casual writing. The tell is the standalone theatrical opener.
- **Real disclaimers.** Keep scope statements, legal and safety notices, corrections, named objections, and FAQ answers.
- **Real alternatives.** Keep options a reader would actually weigh in a design doc, tutorial, or argument. Cut only the unlikely option the text dismisses and never returns to.
- **Missing citations.** Most writing is uncited. That proves nothing.
- **Correct, complex formatting.** Templates and visual editors produce clean output with no AI involved.

When unsure, look for several patterns together. One tell proves nothing. A cluster in one passage is real evidence.

## The dash default

The rewrite ships without em dashes, en dashes used as dashes, spaced hyphens, or double hyphens. Replace each with a period, comma, colon, or parentheses, or rewrite the sentence around it.

Two overrides: the writing sample uses them, or the user asks to keep them.

This is a preference about output, not a claim about the input. See the note above.

## Human details to keep

These carry the writer's voice. Preserve them unless they damage the meaning:

- Specific, odd details. A real address, a strange quote, "the lawyer who used to work upstairs from my dentist."
- Unresolved tension. "I think this is mostly good, but it bothers me and I can't say why."
- Dated references. Slang, memes, and in-jokes tied to a particular year and subculture.
- Deliberate choices the writer can justify.
- Varied sentence length. Real writing alternates short and long; AI writing settles into an even mid-length cadence.
- Genuine asides and self-corrections. "(I keep wanting to say 'almost' here, but it really was certain.)"

## Source

Built on [Wikipedia: Signs of AI writing](https://en.wikipedia.org/wiki/Wikipedia:Signs_of_AI_writing), maintained by WikiProject AI Cleanup, whose patterns come from reviewing AI-generated text on Wikipedia.

Their core observation: "LLMs use statistical algorithms to guess what should come next. The result tends toward the most statistically likely result that applies to the widest variety of cases."
