# Prompt Engineering Frameworks — Deep Reference

*Read this file when you need deeper context on any specific technique, or when you're dealing with a complex prompt that needs more than the basics.*

---

## Table of Contents

1. [The Anatomy of a Great Prompt](#anatomy)
2. [COSTAR-A Framework — Full Guide](#costar)
3. [APE Framework — Action, Purpose, Expectation](#ape)
4. [RTF Framework — Role, Task, Format](#rtf)
5. [Anthropic's 9 Core Techniques (from their official tutorial)](#anthropic)
6. [Chain-of-Thought Prompting](#cot)
7. [Few-Shot / Example Prompting](#few-shot)
8. [XML Tags & Structure](#xml)
9. [System Prompts vs User Prompts](#system-vs-user)
10. [Prompt Chaining](#chaining)
11. [The 12 Failure Modes — Full Before/After Examples](#failure-modes)
12. [Advanced Techniques](#advanced)
13. [Quick Diagnostic Checklist](#checklist)

---

## 1. The Anatomy of a Great Prompt {#anatomy}

Every strong prompt has some combination of these 8 ingredients. Not every prompt needs all 8 — but most bad prompts are missing at least 3.

| Ingredient | What it does | Beginner mistake |
|---|---|---|
| **Role** | Tells AI *who* to be | Skipping it entirely — AI defaults to "helpful assistant" |
| **Context** | Gives AI the background it needs | Assuming AI knows your industry, your business, your goals |
| **Task** | Defines the exact deliverable | Being vague — "write something about X" |
| **Audience** | Tells AI who the output is for | Forgetting this — output ends up calibrated to no one |
| **Tone/Style** | Controls how it sounds | Leaving it blank — AI defaults to neutral, generic, forgettable |
| **Examples** | Shows AI the specific flavor you want | Describing instead of demonstrating |
| **Format** | Defines structure and length | Not specifying — getting a wall of text or a one-liner |
| **Constraints** | Tells AI what to avoid or assume | Only saying what to do, never what NOT to do (or doing it wrong — see negative instructions) |

---

## 2. COSTAR-A Framework {#costar}

COSTAR was developed by data scientist Sheila Teo and became the industry standard after winning Singapore's first GPT-4 Prompt Engineering Competition. The "A" extension (Answer format) was added by researchers to handle output control explicitly.

**C — Context:** What background does the AI need to understand this task properly?
- Your industry, your product, your audience, the history behind the request, any constraints
- Rule of thumb: if a new hire wouldn't know this, the AI doesn't know it either

**O — Objective:** What is the goal of this output? What should it accomplish?
- Not just "write a post" but "write a post that gets people to DM me asking about my coaching program"
- Include the action you want the *reader/recipient* to take

**S — Style:** How should this be written? What voice or writing style?
- Compare to a known voice if helpful: "Write like a smart, direct friend — not a brand"
- Reference genre: "Think newsletter, not blog post"

**T — Tone:** What emotional register? How should this feel?
- Warm, authoritative, urgent, playful, empathetic, bold, calm, provocative
- Tone is different from style. Style = how it's constructed. Tone = how it feels.

**A — Audience:** Who specifically is consuming this?
- Demographics, psychographics, knowledge level, what they believe coming in
- The more specific, the better: "Ambitious but overwhelmed female founders, 32-45, who've tried productivity systems and failed"

**R — Response format:** What does the output look like structurally?
- Length (words, sentences, slides, bullet points)
- Structure (numbered list, table, email format, script with speaker labels, etc.)
- Any specific requirements: include a CTA, end with a question, use subheadings

### COSTAR Template (copy and fill in):

```
[CONTEXT]
You are a [role] who [relevant expertise or perspective].
Background: [relevant info the AI needs about the situation, product, client, etc.]

[OBJECTIVE]
Task: [what you want the AI to produce, and what it should accomplish]

[STYLE]
Write in the style of: [describe the style or compare to a known voice/genre]

[TONE]
Tone: [emotional register — warm, confident, urgent, etc.]

[AUDIENCE]
This is for: [specific description of who will read/use this]

[RESPONSE FORMAT]
Output format: [length + structure + any specific requirements]
```

---

## 3. APE Framework {#ape}

APE is simpler — great for everyday tasks and quick prompts.

**A — Action:** What specific action do you want the AI to perform?
- "Write", "Summarize", "Rewrite", "Analyze", "Generate", "Compare"
- Be verb-specific. "Help me with" is not an action.

**P — Purpose:** Why are you doing this? What's the underlying goal?
- This context helps AI make better judgment calls when instructions are ambiguous

**E — Expectation:** What does success look like?
- Format, length, quality standard, what "good" means in this context

### APE Example:

**Weak:** "Help me write an email to my client."

**APE version:**
- Action: Write a follow-up email
- Purpose: I had a discovery call with a potential client yesterday. They were interested but noncommittal. I want to re-ignite their interest without being pushy.
- Expectation: 150 words max. Warm and confident tone. One clear CTA (book a call). Subject line included.

---

## 4. RTF Framework {#rtf}

RTF is the leanest framework — perfect for fast prompts where you just need to tighten up the basics.

**R — Role:** Who should the AI be?
**T — Task:** What should it do?
**F — Format:** How should the output be structured?

### RTF Example:

**Weak:** "Explain blockchain."

**RTF version:**
```
Role: You are a tech journalist who explains complex topics to general audiences.
Task: Explain how blockchain works in plain English — no jargon, no assumed knowledge.
Format: 3 short paragraphs. Each paragraph = one key idea. End with a one-sentence summary.
```

---

## 5. Anthropic's 9 Core Techniques {#anthropic}

These come directly from Anthropic's Interactive Prompt Engineering Tutorial (available at github.com/anthropics/prompt-eng-interactive-tutorial).

### Chapter 1: Basic Prompt Structure
Every prompt has two parts: the **system prompt** (who the AI is, its context and rules) and the **user message** (the specific request). Most people only use the user message. Adding a system prompt is one of the fastest ways to improve consistency and quality.

### Chapter 2: Being Clear and Direct
The #1 mistake: being vague hoping AI will "figure it out." AI does exactly what you ask — no more, no less. If you're not getting what you want, the problem is almost always in your prompt.

**Rule:** Strip out filler words. Replace hedge language with specific instructions. "Could you maybe write something sort of like..." → "Write a..."

### Chapter 3: Assigning Roles
Putting a role at the very start of your prompt — especially in the system prompt — dramatically changes output quality. Claude (and most LLMs) respond to role context as a frame for all subsequent decisions.

**Bad:** "Write a marketing email."
**Good:** "You are a direct-response copywriter with 15 years of experience writing emails for high-ticket coaching programs. Write a marketing email for..."

Effective role elements:
- Profession or title
- Years of experience or expertise level
- Specific niche or specialty
- Relevant perspective or worldview

### Chapter 4: Separating Data from Instructions
When your prompt includes both instructions AND data/content for the AI to work with, keep them clearly separate. Mixing them causes the AI to confuse what to do with what to work on.

Use XML tags, headers, or line breaks to separate:
- Instructions (what to do)
- Data/content (what to do it to)
- Examples (what good looks like)
- Output format (how to structure the result)

### Chapter 5: Formatting Output & Output Prefilling
Tell the AI exactly how to structure its response. Don't assume it will guess right.

For Claude specifically: you can "prefill" the response by starting the AI's reply for it. This forces it to continue in the direction you've set.

Example: "Begin your response with: 'Here are 5 subject lines, ranked from most bold to most safe:'"

### Chapter 6: Precognition / Chain-of-Thought
For complex or analytical tasks, instruct the AI to think before it answers. This sounds simple but it dramatically improves accuracy.

**Trigger phrases:**
- "Think step by step before answering."
- "Before writing, reason through the key considerations."
- "First outline your approach, then execute it."
- "Use a <thinking> block to work through this, then give your final answer."

Chain-of-thought works best for: math, logic, analysis, strategy, anything where the answer depends on getting the reasoning right.

### Chapter 7: Using Examples (Few-Shot Prompting)
The fastest way to get the exact style, tone, or format you want. Show 1-3 examples of what "good" looks like. This is called "few-shot prompting."

**Zero-shot:** "Write a tweet about productivity."
**One-shot:** "Write a tweet about productivity. Here's an example of the style I want: [example tweet]"
**Few-shot:** Same but 2-3 examples.

The examples calibrate the AI's internal model of what you want. They're more powerful than lengthy style descriptions.

### Chapter 8: Avoiding Hallucinations
AI makes things up when it doesn't know something — and it often does it confidently. Reduce hallucination risk by:

1. Telling the AI to say "I don't know" when uncertain: "If you're not confident about a fact, say so."
2. Asking it to cite or reference sources when relevant
3. Providing the source material yourself instead of asking AI to recall it
4. Breaking tasks into steps where each step can be verified
5. Adding: "Only include information you are certain of."

### Chapter 9: Building Complex Prompts from Scratch
For complex tasks, build your prompt systematically:

1. Start with the role and context
2. Define the task and objective
3. Add audience and tone
4. Include examples
5. Define the output format
6. Add any constraints or guardrails
7. Read it back as if you're the AI — would you know exactly what to produce?

---

## 6. Chain-of-Thought Prompting {#cot}

Chain-of-thought (CoT) forces the model to reason through a problem rather than pattern-match to a quick answer. It's the difference between asking someone to answer off the top of their head vs. asking them to show their work.

**When to use it:**
- Math or calculations
- Multi-step analysis
- Strategy or recommendations
- Troubleshooting
- Legal, financial, or medical reasoning
- Any situation where the *reasoning process* matters as much as the answer

**How to trigger it:**
- "Think step by step."
- "Before answering, reason through all the factors involved."
- "Walk me through your thinking first."
- "Show your work, then give your conclusion."

**XML scratchpad approach (for Claude):**
```
Think through this problem carefully in a <thinking> block, then provide your final answer.

<thinking>
[Claude will reason here before answering]
</thinking>

Final answer: [Claude gives the answer here]
```

---

## 7. Few-Shot / Example Prompting {#few-shot}

Examples are the most underused technique in prompting. People spend paragraphs describing the style they want when a single example would communicate it instantly.

### Structure:

```
Here are examples of the output style I want:

Example 1:
[your example]

Example 2:
[your example]

Now write: [your actual request]
```

### What to use examples for:
- Tone and voice matching (especially for brands with a distinctive voice)
- Specific format or structure
- The level of technical detail you want
- What you consider "too formal" or "too casual"
- The exact kind of hook, CTA, or opening you prefer

### Pro tip: Negative examples
You can show the AI what you *don't* want too:

```
Do NOT write in this style:
[example of bad style]

DO write in this style:
[example of good style]
```

---

## 8. XML Tags & Structure {#xml}

Claude (Anthropic's AI) is trained to respond especially well to XML-style tags because they clearly delineate different sections of a prompt. Other AI models also benefit from structured prompts — the tags make it impossible for the model to confuse context with instructions with data.

### Most useful tags:

```xml
<context>
Background information the AI needs
</context>

<instructions>
Step-by-step instructions for what to do
</instructions>

<examples>
Example inputs and outputs
</examples>

<content>
The actual content or data you want the AI to work with
</content>

<output_format>
How you want the response structured
</output_format>

<constraints>
What to avoid, what to assume, any guardrails
</constraints>

<thinking>
[Claude uses this space to reason before answering — great for complex tasks]
</thinking>
```

### When XML is most valuable:
- Long prompts with multiple sections
- Prompts that include both instructions AND content to process
- System prompts for AI assistants or agents
- When you've had problems with the AI mixing up different parts of your prompt

---

## 9. System Prompts vs. User Prompts {#system-vs-user}

Most people only use the user message. Adding a **system prompt** is one of the most underused improvements available.

**System prompt:** Sets the permanent context — who the AI is, what it knows, how it behaves, what it should always or never do. Think of it as the AI's "briefing" before every conversation.

**User message:** The specific, per-conversation request.

### System prompt uses:
- Define the AI's role and expertise
- Set tone and communication style (always)
- Give background about you, your business, your audience
- Establish rules ("always use metric units", "never recommend competitors", "respond only in Spanish")
- Set output defaults (always use bullet points, always ask a follow-up question, etc.)

### Example system prompt for a business assistant:

```
You are a senior marketing strategist with 12 years of experience working with SaaS companies. 

You're assisting the founder of AI Savvy CEO, an online education brand that teaches non-technical business owners to use AI tools. The audience is female founders aged 30-50 who are ambitious but overwhelmed by tech.

Communication style: Smart and direct but warm. No jargon. Explain concepts with analogies. Short paragraphs.

Default behavior: When asked to write content, always ask for the intended platform and audience if not specified.
```

---

## 10. Prompt Chaining {#chaining}

Complex tasks fail when you try to do everything in one prompt. Prompt chaining breaks the work into a sequence of focused prompts where each output feeds into the next.

**Common chains:**

Research → Outline → Draft → Edit → Format

Brainstorm → Filter → Develop → Polish

Analyze → Identify gaps → Write to fill them → Summarize

**When to chain:**
- The task has multiple distinct phases
- You need to review/approve an intermediate step before proceeding
- Quality is dropping because the prompt is trying to do too much
- You're getting inconsistent results from a single large prompt

**How to structure a chain:**

Prompt 1: "Analyze this transcript and identify the 5 most interesting insights."
→ Review output →
Prompt 2: "Using these 5 insights, create an outline for a LinkedIn post."
→ Review output →
Prompt 3: "Write the full LinkedIn post based on this outline. Tone: [X]. Audience: [Y]."

---

## 11. The 12 Failure Modes — Full Before/After Examples {#failure-modes}

### Failure Mode 1: Vagueness

**Before:** "Write a social media post."

**After:**
```
Write an Instagram caption for a post about time-blocking for busy entrepreneurs.
Tone: Practical and energizing — like a coach giving real advice, not fluff.
Audience: Female entrepreneurs, 30-45, overwhelmed, looking for quick wins.
Format: 3 short paragraphs + 3-5 relevant hashtags. Under 150 words.
```

---

### Failure Mode 2: Missing Context

**Before:** "Write a response to this customer complaint." [no complaint included, no context about company]

**After:**
```
Context: I run a small online coaching business. A client is upset because they didn't get the promised email follow-up after their session. This is due to a system error — it's our fault. The client paid $350 for the session.

Complaint: [paste the complaint]

Task: Write a professional, empathetic response that:
- Acknowledges the mistake without making excuses
- Apologizes sincerely
- Offers a concrete solution (I'll offer a free 30-minute follow-up call)
- Maintains our brand voice: warm, accountable, professional
```

---

### Failure Mode 3: No Role Assigned

**Before:** "Explain how to run Facebook ads."

**After:**
```
You are a paid media strategist with 8 years of experience running Facebook ads for coaches and course creators with budgets between $500-5000/month.

Explain how to set up and run Facebook ads for someone who:
- Has never run ads before
- Is selling a $97 online course
- Has a $500/month budget

Skip the theory. Give me practical, sequenced steps. Use plain language — no ad platform jargon without explanation.
```

---

### Failure Mode 4: No Audience Defined

**Before:** "Write a blog post about AI tools."

**After:**
```
Write a blog post about AI tools for non-technical female business owners who are curious but intimidated by tech. 

Assume they use Google Docs, Canva, and Instagram — and that's about as technical as it gets. They've heard about ChatGPT but haven't really used it yet.

Tone: Like a trusted friend who's a year ahead of them on this journey. No judgment. No hype.
Length: 600-800 words.
Structure: Intro hook + 3 tools with what each one does + closing encouragement.
```

---

### Failure Mode 5: No Format Specified

**Before:** "Summarize this article for me."

**After:**
```
Summarize this article. Format:
- 3 bullet points covering the main ideas
- 1 sentence on why this matters
- 1 key takeaway I can apply today

Keep it under 100 words total.

Article: [paste article]
```

---

### Failure Mode 6: No Examples

**Before:** "Write copy in my brand voice."

**After:**
```
Write copy in my brand voice. Here are 3 examples of my existing content so you can match the style:

Example 1: [paste example]
Example 2: [paste example]
Example 3: [paste example]

Now write: [your request]

Match the vocabulary, sentence length, and energy of the examples above.
```

---

### Failure Mode 7: Negative Instructions

**Before:** "Don't make it sound too formal or too casual and don't use buzzwords."

**After:**
```
Write in a conversational, direct tone — like a knowledgeable friend giving real advice. Short sentences. Plain words. No industry jargon. If a word feels fancy or corporate, swap it for a simpler one.
```

---

### Failure Mode 8: Overloaded Prompt

**Before:** "Research AI trends, write a blog post about them, make it SEO-friendly, come up with 5 social media posts based on it, and create an email newsletter version too."

**After (broken into a chain):**

Prompt 1: "Research the top 5 AI trends relevant to small business owners in 2026. For each trend: what it is, why it matters, and one practical example. Bullet format. Source any claims."

→ Review →

Prompt 2: "Using these 5 trends, write a 700-word blog post for non-technical business owners. [tone/format specs]"

→ Review →

Prompt 3: "Based on this blog post, write 5 standalone Instagram captions. One per trend."

→ Review →

Prompt 4: "Adapt this blog post into a 250-word email newsletter. Subject line included."

---

### Failure Mode 9: Missing Tone/Style

**Before:** "Write product descriptions for my skincare line."

**After:**
```
Write product descriptions for a luxury natural skincare line. 

Tone: Calm, sophisticated, and sensory. The copy should make the reader feel like they're reading poetry — not a label. Think Aesop or Glossier at its most elevated.

What to avoid: Clinical language, ingredient lists, claims like "anti-aging." Focus on experience and feeling, not features.

Product details: [paste product info]

Format: 60-80 words per product. One flowing paragraph. No bullet points.
```

---

### Failure Mode 10: No Length/Scope

**Before:** "Give me some ideas for content."

**After:**
```
Give me 10 content ideas for Instagram Reels. Topic area: Using AI tools to save time as a coach or consultant.

Format: Numbered list. Each idea = 1 sentence describing the concept + 1 sentence on the hook (what makes someone stop scrolling).

Target audience: Female coaches, consultants, and course creators, 30-50.
```

---

### Failure Mode 11: Missing Purpose

**Before:** "Write a thank you email."

**After:**
```
Write a thank you email to someone who just purchased my $1,997 "AI Savvy Founder" online course.

Purpose: Make them feel confident and excited — reduce any buyer's remorse and set expectations for what happens next (they'll get an onboarding email in 24 hours, course access within 48 hours).

Tone: Warm, genuine, personal — not corporate. Like the founder is personally writing to them.
Format: Email with subject line. Max 200 words.
```

---

### Failure Mode 12: No Constraints/Guardrails

**Before:** "Write 10 ad hooks for my program."

**After:**
```
Write 10 ad hooks for my online course "AI for Non-Tech Founders" ($497 program).

Constraints:
- Do NOT use the word "easy" or "simple" — our audience hates that
- Do NOT make claims we can't back up (e.g., exact income results)
- DO reference time savings — our audience values their time above everything
- Do NOT use exclamation marks
- Audience: Skeptical, smart founders who've been burned by hype before — speak to them with respect, not hype

Format: Numbered list. One hook per line. Under 20 words each.
```

---

## 12. Advanced Techniques {#advanced}

### Temperature awareness
Most AI interfaces let you control "temperature" (randomness/creativity). Low temperature = more consistent, predictable. High temperature = more creative, varied. When consistency matters, use low temperature. When you want novel ideas, use higher.

### Output prefilling (Claude-specific)
Start Claude's response for it to force it into a specific direction:
"Start your response with: 'The three most important things to know are:'"

### Iterative prompting
Treat prompting as a conversation, not a one-shot. After getting a response:
- "Make it 30% shorter."
- "Make the opening hook more provocative."
- "Keep everything but rewrite it as if speaking directly to a 25-year-old."
- "This is good — now remove all the adjectives."

### Meta-prompting
Ask the AI to help you write a better prompt:
"I want to prompt you to [task]. What information do you need from me to give the best possible output?"

### Role + expertise combo
The most powerful role assignments combine a profession WITH a specific lens:
- "You are a UX researcher who specializes in cognitive load"
- "You are a copywriter who has studied direct-response advertising for 20 years"
- "You are a financial advisor who communicates complex topics to complete beginners"

### Self-critique loop
Ask the AI to review its own work:
"Now review your response. What's the weakest part? Rewrite that section."

Or: "Rate your response on a scale of 1-10 for [quality criteria]. Then improve it."

---

## 13. Quick Diagnostic Checklist {#checklist}

Before sending any prompt, run through this fast:

- [ ] Does the AI know who it should *be*? (role)
- [ ] Does the AI have enough *background*? (context)
- [ ] Is the *task* crystal clear — specific verb, specific deliverable?
- [ ] Does the AI know who this is *for*? (audience)
- [ ] Is the *tone/style* defined, not just implied?
- [ ] Did I show any *examples* of what good looks like?
- [ ] Did I specify the *format and length*?
- [ ] Did I say what this output needs to *accomplish*? (purpose/objective)
- [ ] Are my constraints framed as *what to do* rather than what not to do?
- [ ] Is this prompt trying to do too much? (*Should I chain this?*)

If 3 or more boxes are unchecked — rebuild before sending.
